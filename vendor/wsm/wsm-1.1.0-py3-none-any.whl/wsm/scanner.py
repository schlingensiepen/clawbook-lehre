"""Scan project directories, detect git repos and categorize by devstate."""

import logging
import subprocess
from pathlib import Path

from wsm.models import (
    Config,
    DevState,
    DEVSTATE_DISPLAY_ORDER,
    DEVSTATE_FILE_MAP,
    Location,
    ProjectInfo,
)

logger = logging.getLogger("wsm")


def git_run(cmd: list[str], cwd: Path, timeout: int = 10, verbose: bool = False) -> str | None:
    """Execute a git command directly (no WSL) and return stdout.

    Args:
        cmd: Git sub-command and arguments.
        cwd: Working directory.
        timeout: Timeout in seconds.
        verbose: If True, print stdout/stderr to console instead of capturing.

    Returns None on failure (non-zero exit code, timeout, or git not found).
    """
    try:
        if verbose:
            result = subprocess.run(
                ["git"] + cmd,
                text=True,
                timeout=timeout,
                cwd=str(cwd),
            )
        else:
            result = subprocess.run(
                ["git"] + cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=str(cwd),
            )
        if result.returncode != 0:
            return None
        return (result.stdout.strip() if not verbose else "") or ""
    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        logger.debug("Git command failed: git %s (%s)", " ".join(cmd), exc)
        return None


def wsl_run(cmd: str, distro: str, timeout: int = 10) -> str | None:
    """Execute a command inside WSL and return stdout.

    Returns None on failure (non-zero exit code, timeout, or WSL not found).
    """
    try:
        result = subprocess.run(
            ["wsl", "-d", distro, "--", "bash", "-c", cmd],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            logger.debug("WSL command failed (rc=%d): %s", result.returncode, cmd[:60])
            return None
        return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        logger.warning("WSL command failed: %s (%s)", cmd[:60], exc)
        return None


def scan_location(location: Location) -> list[ProjectInfo]:
    """Scan a location directory and return project info for each subdirectory.

    Skips the template directory. Does NOT fetch git details (branch/commit)
    to keep scanning fast. Use fetch_git_info() for that.
    """
    projects: list[ProjectInfo] = []
    loc_path = location.path

    if not loc_path.exists():
        logger.warning("Location existiert nicht: %s", loc_path)
        return projects

    for entry in sorted(loc_path.iterdir()):
        if not entry.is_dir():
            continue
        if location.template and entry.name == location.template:
            continue
        if entry.name.startswith("."):
            continue

        project = _analyze_project(entry, location)
        projects.append(project)

    return projects


def _analyze_project(path: Path, location: Location) -> ProjectInfo:
    """Analyze a single project directory (fast, no git calls)."""
    project = ProjectInfo(
        name=path.name,
        path=path,
        location=location,
    )

    # Check for .git directory
    git_dir = path / ".git"
    if not git_dir.exists():
        project.devstate = DevState.NO_GIT
        return project

    project.is_git_repo = True
    project.devstate = _detect_devstate(path)
    return project


def fetch_git_info(project: ProjectInfo) -> None:
    """Fetch git branch and last commit for a project using git.exe directly.

    Modifies the ProjectInfo in place.
    """
    if not project.is_git_repo:
        return

    branch = git_run(["branch", "--show-current"], cwd=project.path)
    project.git_branch = branch or "(detached)"

    commit = git_run(["log", "--oneline", "-1"], cwd=project.path)
    project.git_last_commit = commit or "(leer)"


def fetch_remote_status(project_path: Path) -> list[dict]:
    """Fetch remote names and ahead/behind status for each.

    Returns a list of dicts with keys: name, url, ahead, behind.
    Returns empty list if no remotes or not a git repo.
    """
    remotes_raw = git_run(["remote", "-v"], cwd=project_path)
    if not remotes_raw:
        return []

    # Parse unique remote names
    seen = set()
    remotes = []
    for line in remotes_raw.splitlines():
        parts = line.split()
        if len(parts) >= 2:
            name = parts[0]
            url = parts[1]
            if name not in seen:
                seen.add(name)
                remotes.append({"name": name, "url": url, "ahead": 0, "behind": 0})

    # Fetch (quick, non-blocking) to update remote refs
    git_run(["fetch", "--all", "--quiet"], cwd=project_path, timeout=15)

    # Get ahead/behind for current branch vs each remote
    branch = git_run(["branch", "--show-current"], cwd=project_path)
    if not branch:
        return remotes

    for remote in remotes:
        rev_list = git_run(
            ["rev-list", "--left-right", "--count", f"{remote['name']}/{branch}...HEAD"],
            cwd=project_path,
        )
        if rev_list:
            parts = rev_list.split()
            if len(parts) == 2:
                remote["behind"] = int(parts[0])
                remote["ahead"] = int(parts[1])

    return remotes


def _detect_devstate(path: Path) -> DevState:
    """Detect the devstate from devstate_*.md files in the project root."""
    for filename, state in DEVSTATE_FILE_MAP.items():
        if (path / filename).exists():
            return state
    return DevState.UNPROCESSED


def group_projects(projects: list[ProjectInfo]) -> dict[DevState, list[ProjectInfo]]:
    """Group projects by devstate category in display order.

    Returns a dict with categories as keys,
    each containing an alphabetically sorted list of projects.
    Only non-empty categories are included.
    """
    groups: dict[DevState, list[ProjectInfo]] = {}
    for state in DEVSTATE_DISPLAY_ORDER:
        matching = sorted(
            [p for p in projects if p.devstate == state],
            key=lambda p: p.name.lower(),
        )
        if matching:
            groups[state] = matching
    return groups


def scan_all_locations(config: Config) -> dict[Location, dict[DevState, list[ProjectInfo]]]:
    """Scan all configured locations and return grouped projects per location."""
    result = {}
    for location in config.locations:
        projects = scan_location(location)
        grouped = group_projects(projects)
        result[location] = grouped
    return result


def find_project(
    name: str,
    config: Config,
    location_filter: Path | None = None,
) -> list[ProjectInfo]:
    """Find projects by name across all (or filtered) locations.

    Returns a list of matching ProjectInfo objects (may be 0, 1, or multiple).
    """
    matches = []
    for location in config.locations:
        if location_filter and location.path != location_filter:
            continue
        project_path = location.path / name
        if project_path.is_dir():
            project = _analyze_project(project_path, location)
            matches.append(project)
    return matches
