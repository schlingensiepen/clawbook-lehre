"""File classification and archive extraction.

Pure file-type logic and archive extraction. No network dependencies —
this module is safe to import without httpx installed.

Consumers that only need file classification (e.g. `scripts/convert_missing.py`)
should import from here directly instead of from `wsm.converter`.
"""

import logging
import tarfile
import zipfile
from pathlib import Path

try:
    import py7zr
except ImportError:
    py7zr = None

try:
    import rarfile
except ImportError:
    rarfile = None

logger = logging.getLogger("wsm")

# File extensions that are just copied (no docling conversion needed)
PASSTHROUGH_EXTENSIONS = {".md", ".txt", ".html", ".htm", ".csv", ".json", ".yaml", ".yml", ".xml"}

# Files to skip entirely (OS metadata, lock files, temp files)
SKIP_FILENAMES = {"Thumbs.db", "desktop.ini", ".DS_Store", "winmail.dat"}
SKIP_PREFIXES = ("~$", ".~lock.")
SKIP_EXTENSIONS = {".tmp", ".emessage"}

# Image extensions — handled by Ollama vision instead of Docling
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp", ".gif", ".jfif"}

# Archive extensions that can be extracted
ARCHIVE_EXTENSIONS_STDLIB = {".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz"}
ARCHIVE_EXTENSIONS_7Z = {".7z"}
ARCHIVE_EXTENSIONS_RAR = {".rar"}

# Whitelist: extensions Docling can convert to Markdown.
# Anything not in this set (and not passthrough/image/archive/skip) is
# categorized as "unsupported" and not sent to Docling.
DOCLING_SUPPORTED = {
    ".pdf",
    ".docx",
    ".pptx",
    ".xlsx",
    ".asciidoc",
    ".adoc",
}

# File categories (for the unified categorize_file() function)
CATEGORY_SKIP = "skip"
CATEGORY_PASSTHROUGH = "passthrough"
CATEGORY_IMAGE = "image"
CATEGORY_ARCHIVE = "archive"
CATEGORY_DOCLING = "docling"
CATEGORY_UNSUPPORTED = "unsupported"


def is_passthrough(file_path: Path) -> bool:
    """Check if a file should be copied as-is without docling conversion."""
    return file_path.suffix.lower() in PASSTHROUGH_EXTENSIONS


def is_image(file_path: Path) -> bool:
    """Check if a file is an image (handled by Ollama vision, not Docling)."""
    return file_path.suffix.lower() in IMAGE_EXTENSIONS


def is_skippable(file_path: Path) -> bool:
    """Check if a file should be ignored entirely (OS metadata, lock files, etc.)."""
    name = file_path.name
    if name in SKIP_FILENAMES:
        return True
    if any(name.startswith(p) for p in SKIP_PREFIXES):
        return True
    if file_path.suffix.lower() in SKIP_EXTENSIONS:
        return True
    return False


def is_archive(file_path: Path) -> bool:
    """Check if a file is an extractable archive."""
    return _archive_type(file_path) is not None


def is_docling_supported(file_path: Path) -> bool:
    """Check if Docling can convert this file format to Markdown."""
    return file_path.suffix.lower() in DOCLING_SUPPORTED


def categorize_file(file_path: Path) -> str:
    """Classify a file into one of the processing categories.

    Returns one of: CATEGORY_SKIP, CATEGORY_PASSTHROUGH, CATEGORY_IMAGE,
    CATEGORY_ARCHIVE, CATEGORY_DOCLING, CATEGORY_UNSUPPORTED.

    Order matters: skip → archive → passthrough → image → docling → unsupported.
    """
    if is_skippable(file_path):
        return CATEGORY_SKIP
    if is_archive(file_path):
        return CATEGORY_ARCHIVE
    if is_passthrough(file_path):
        return CATEGORY_PASSTHROUGH
    if is_image(file_path):
        return CATEGORY_IMAGE
    if is_docling_supported(file_path):
        return CATEGORY_DOCLING
    return CATEGORY_UNSUPPORTED


def _archive_type(file_path: Path) -> str | None:
    """Return the archive type string or None if not an archive."""
    name_lower = file_path.name.lower()
    # Check compound extensions first (.tar.gz, .tar.bz2, .tar.xz)
    for ext in (".tar.gz", ".tar.bz2", ".tar.xz"):
        if name_lower.endswith(ext):
            return "tar"
    suffix = file_path.suffix.lower()
    if suffix in (".tar", ".tgz"):
        return "tar"
    if suffix == ".zip":
        return "zip"
    if suffix == ".7z" and py7zr is not None:
        return "7z"
    if suffix == ".rar" and rarfile is not None:
        return "rar"
    return None


def extract_archive(archive_path: Path, target_dir: Path) -> list[Path]:
    """Extract an archive to target_dir and return list of extracted files.

    The target_dir is named after the archive (without extension).
    If target_dir already exists, extraction is skipped and existing files returned.

    Returns:
        List of extracted file paths.
    """
    if target_dir.exists():
        logger.debug("Archiv bereits entpackt: %s", target_dir)
        return [f for f in sorted(target_dir.rglob("*")) if f.is_file()]

    atype = _archive_type(archive_path)
    if atype is None:
        return []

    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        if atype == "zip":
            with zipfile.ZipFile(archive_path, "r") as zf:
                zf.extractall(target_dir)
        elif atype == "tar":
            with tarfile.open(archive_path, "r:*") as tf:
                tf.extractall(target_dir, filter="data")
        elif atype == "7z" and py7zr is not None:
            with py7zr.SevenZipFile(archive_path, "r") as sz:
                sz.extractall(target_dir)
        elif atype == "rar" and rarfile is not None:
            with rarfile.RarFile(archive_path, "r") as rf:
                rf.extractall(target_dir)
        else:
            return []
    except Exception as exc:
        logger.warning("Fehler beim Entpacken von %s: %s", archive_path.name, exc)
        return []

    extracted = [f for f in sorted(target_dir.rglob("*")) if f.is_file()]
    logger.info("Entpackt: %s → %d Dateien in %s", archive_path.name, len(extracted), target_dir)
    return extracted
