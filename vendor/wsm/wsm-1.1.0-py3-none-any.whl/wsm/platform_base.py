"""Abstract base class for platform-specific operations."""

from abc import ABC, abstractmethod
from pathlib import Path


class PlatformBackend(ABC):
    """Platform abstraction for OS-specific operations.

    Concrete implementations: WindowsBackend, LinuxBackend.
    """

    @abstractmethod
    def launch_claude(
        self,
        project_path: Path,
        distro: str,
        prompt: str | None = None,
        resume: bool = False,
    ) -> bool:
        """Launch Claude Code in a new window/session."""
        ...

    @abstractmethod
    def launch_sync(
        self,
        project_name: str | None = None,
        config_path: Path | None = None,
    ) -> bool:
        """Launch a background sync in a separate window/session."""
        ...

    @abstractmethod
    def launch_export(
        self,
        project_paths: list[Path],
        config_path: Path | None = None,
    ) -> bool:
        """Launch `wsm export <paths...>` in a separate window/session.

        Project paths are passed as positional arguments to the subprocess.
        On Windows, paths are quoted to handle spaces and UNC paths.
        """
        ...

    @abstractmethod
    def launch_push(
        self,
        project_paths: list[Path],
        config_path: Path | None = None,
    ) -> bool:
        """Launch `wsm push <paths...>` in a separate window/session.

        Sequential 'git push -u origin main' per path. No timeout, so big
        repos don't hit the spurious 'fehlgeschlagen' marker the previous
        synchronous variant produced.
        """
        ...

    @abstractmethod
    def open_explorer(self, project_path: Path) -> bool:
        """Open a file manager at the given path."""
        ...

    @abstractmethod
    def open_editor(self, file_path: Path) -> bool:
        """Open a file in the system editor."""
        ...

    @abstractmethod
    def open_shell(self, project_path: Path) -> bool:
        """Open a shell/terminal at the given path.

        Windows: opens cmd.exe in a new window.
        Linux: opens a tmux session in the foreground (blocks until exit).
        """
        ...

    @abstractmethod
    def open_powershell(self, project_path: Path) -> bool:
        """Open PowerShell at the given path.

        Windows: opens PowerShell in a new window.
        Linux: opens pwsh if available, otherwise falls back to bash.
        """
        ...

    @abstractmethod
    def read_clipboard_paths(self) -> list[Path]:
        """Read file/folder paths from the system clipboard."""
        ...

    @abstractmethod
    def restore_console(self) -> None:
        """Restore console mode after subprocess launch."""
        ...
