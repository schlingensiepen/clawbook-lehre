"""CLI argument parsing and command dispatch."""

import argparse
import asyncio
import logging
import sys
import time
from pathlib import Path

from wsm.clipboard import classify_clipboard_paths, read_clipboard_paths
from wsm.config import default_config_path, load_config, save_config
from wsm.converter import DoclingPool, OllamaPool
from wsm.launcher import (
    launch_claude,
    launch_push,
    launch_sync,
    open_explorer,
    open_powershell,
    open_shell,
)
from wsm.log import setup_logging
from wsm.models import Config, DocSources, Location, Source
from wsm.paths import expand_tilde, sanitize_name
from wsm.scanner import fetch_git_info, fetch_remote_status, find_project, group_projects, scan_location
from wsm.sources import (
    copy_files_to_raw,
    get_data_detail,
    get_data_summary,
    load_doc_sources,
    save_doc_sources,
    sync_project,
)
from wsm.ui.terminal import (
    ask_text,
    confirm,
    console,
    print_clipboard_preview,
    print_error,
    print_header,
    print_info,
    print_success,
    print_sync_summary,
    print_warning,
    print_project_list,
    select_action,
    select_location,
    select_multi_projects,
    select_project,
    select_prompt,
    show_project_data,
    show_project_detail,
)
from wsm.workspace import (
    compute_template_gaps,
    create_project,
    has_commits,
    has_remote,
    init_full,
    init_git,
    init_template,
    _resolve_template_path,
)

logger = logging.getLogger("wsm")


def _get_paths_interactive() -> list[Path]:
    """Ask the user for paths when the clipboard is empty.

    Accepts one or more paths (files or directories), separated by newlines.
    The user can paste paths that were copied via "Copy as path" in Explorer.
    Strips quotes that Windows adds around paths.
    """
    print_warning("Zwischenablage ist leer oder enthaelt keine Dateien.")
    console.print("  Pfade eingeben (einzeln oder mehrere Zeilen, leere Zeile zum Beenden):")

    lines: list[str] = []
    while True:
        try:
            line = input("    > ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not line:
            break
        lines.append(line)

    paths: list[Path] = []
    for line in lines:
        # Strip surrounding quotes (Windows "Copy as path" adds them)
        cleaned = line.strip().strip('"').strip("'")
        if not cleaned:
            continue
        p = Path(cleaned)
        if p.exists():
            paths.append(p)
        else:
            console.print(f"    [yellow]Nicht gefunden:[/] {cleaned}")
    return paths


def _read_paths() -> list[Path]:
    """Read paths from clipboard, falling back to interactive input."""
    paths = read_clipboard_paths()
    if not paths:
        paths = _get_paths_interactive()
    return paths


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="wsm",
        description="Workspace Manager - manage development projects with Claude Code in WSL",
    )

    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Alternativer Config-Pfad",
    )
    parser.add_argument(
        "--location",
        type=str,
        default=None,
        help="Location vorwaehlen",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Ausfuehrliche Ausgabe",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Nur anzeigen, nichts aendern",
    )

    sub = parser.add_subparsers(dest="command")

    # start (default)
    start_p = sub.add_parser("start", help="Interaktiver Start-Modus")
    start_p.add_argument("project", nargs="?", help="Projektname")
    start_p.add_argument("--resume", action="store_true", help="Letzte Session fortsetzen")
    start_p.add_argument("--prompt", type=str, help="Benannter Prompt")

    # create
    create_p = sub.add_parser("create", help="Neues Projekt anlegen")
    create_p.add_argument("name", nargs="?", help="Projektname")

    # update
    update_p = sub.add_parser("update", help="Quellen synchronisieren")
    update_p.add_argument("project", nargs="?", help="Projektname")
    update_p.add_argument(
        "--workers", "-w",
        type=int,
        default=None,
        help="Workers pro Docling-Server (Default: aus Config)",
    )

    # copy
    copy_p = sub.add_parser("copy", help="Dateien aus Zwischenablage kopieren")
    copy_p.add_argument("project", nargs="?", help="Projektname")

    # import
    import_p = sub.add_parser("import", help="Dateien aus Zwischenablage importieren")
    import_p.add_argument("project", nargs="?", help="Projektname")

    # link
    link_p = sub.add_parser("link", help="Quellen aus Zwischenablage verlinken")
    link_p.add_argument("project", nargs="?", help="Projektname")

    # export
    export_p = sub.add_parser(
        "export",
        help="Projekte als 7z-Archive exportieren (sequenziell)",
    )
    export_p.add_argument(
        "paths",
        nargs="+",
        type=Path,
        help="Projektpfade (mindestens einer)",
    )

    # push
    push_p = sub.add_parser(
        "push",
        help="Initialer git push fuer ein oder mehrere Projekte (sequenziell)",
    )
    push_p.add_argument(
        "paths",
        nargs="+",
        type=Path,
        help="Projektpfade (mindestens einer)",
    )

    # config
    config_p = sub.add_parser("config", help="Konfiguration verwalten")
    config_p.add_argument("--validate", action="store_true", help="Config pruefen")
    config_p.add_argument("--init", action="store_true", help="Config anlegen")
    config_p.add_argument("--edit", action="store_true", help="Config im Editor oeffnen")
    config_p.add_argument("--path", action="store_true", help="Config-Pfad ausgeben")

    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)

    command = args.command or "start"

    # Handle config commands before loading config
    if command == "config":
        return _cmd_config(args)

    # Load config
    try:
        config = load_config(args.config)
    except (FileNotFoundError, ValueError) as exc:
        print_error(str(exc))
        return 1

    # Setup logging
    setup_logging(log_file=config.log_file, verbose=args.verbose)

    # Resolve location filter
    location_filter = None
    if args.location:
        location_filter = expand_tilde(args.location)

    # Dispatch command
    try:
        if command == "start":
            return _cmd_start(config, args, location_filter)
        elif command == "create":
            return _cmd_create(config, args, location_filter)
        elif command == "update":
            return _cmd_update(config, args, location_filter)
        elif command == "copy":
            return _cmd_clipboard_data(config, args, location_filter, mode="copy")
        elif command == "import":
            return _cmd_clipboard_data(config, args, location_filter, mode="import")
        elif command == "link":
            return _cmd_link(config, args, location_filter)
        elif command == "export":
            return _cmd_export(config, args)
        elif command == "push":
            return _cmd_push(args)
        else:
            parser.print_help()
            return 1
    except KeyboardInterrupt:
        console.print("\n  [dim]Abgebrochen.[/]")
        return 0


# ── Command implementations ─────────────────────────────────────────


def _cmd_start(config: Config, args: argparse.Namespace, location_filter: Path | None) -> int:
    """Interactive start mode."""
    print_header()

    # Direct project start via CLI args
    if hasattr(args, "project") and args.project:
        return _direct_start(config, args)

    # Resolve available locations
    locations = config.locations
    if location_filter:
        locations = [loc for loc in locations if loc.path == location_filter]
        if not locations:
            print_error(f"Location nicht gefunden: {location_filter}")
            return 1

    # Outer loop: location selection with [U] sync
    while True:
        labels = [str(loc.path) for loc in locations]
        result = select_location(labels, show_sync=True)

        if result is None:
            console.print("  [dim]Bye.[/]")
            return 0
        if result == "u":
            config_path = args.config or None
            if launch_sync(None, config_path):
                print_success("Sync fuer alle Projekte gestartet.")
            else:
                print_warning("Sync-Fenster konnte nicht geoeffnet werden.")
            continue

        location = locations[result]

        # Inner loop: project selection within location.
        # `annotations` is set by [D] Details and applied to exactly one
        # subsequent render. Reset to None after each render -- so any
        # following action (or another [D]) starts from a clean state.
        annotations = None
        while True:
            projects = scan_location(location)
            grouped = group_projects(projects)
            flat_list = print_project_list(
                grouped, str(location.path), annotations=annotations,
            )
            # Annotations apply to exactly one render; clear them now so
            # the next iteration falls back to the fast default view.
            annotations = None

            if not flat_list:
                print_warning("Keine Projekte gefunden.")
                if confirm("Neues Projekt anlegen?"):
                    _cmd_create_interactive(config, location, args=args)
                    continue
                break  # Back to location selection

            selection = select_project(flat_list)

            if selection is None:
                break  # Back to location selection
            if selection == "n":
                _cmd_create_interactive(config, location, args=args)
                continue
            if selection == "m":
                _do_multi_start(flat_list, config, location)
                continue
            if selection == "f":
                _do_multi_init(flat_list, args)
                continue
            if selection == "z":
                _do_multi_zip(flat_list, config, args)
                continue
            if selection == "r":
                _do_remote_check_all(flat_list, args)
                continue
            if selection == "d":
                # Compute annotations (slow: fetch + template-walk per project)
                # and let the next loop iteration render them. The next
                # iteration also clears `annotations` immediately after, so
                # a subsequent action returns to the fast default view.
                annotations = compute_details_map(flat_list)
                continue

            project = selection
            _project_action_loop(project, config, args)


def _project_action_loop(project, config, args):
    """Handle the action menu for a selected project."""
    # Fetch git info once when entering the detail view
    fetch_git_info(project)
    data_summary = get_data_summary(project.path)

    while True:
        show_project_detail(project, data_summary)
        template_has_gaps = bool(_project_template_gaps(project))
        action = select_action(project.is_git_repo, template_has_gaps)

        if action == "q":
            break
        elif action == "s":
            _do_start(project, config)
        elif action == "c":
            _do_clipboard_data(project, move=False)
            data_summary = get_data_summary(project.path)
        elif action == "i":
            _do_clipboard_data(project, move=True)
            data_summary = get_data_summary(project.path)
        elif action == "l":
            _do_link(project)
            data_summary = get_data_summary(project.path)
        elif action == "u":
            _do_sync(project, config, args)
        elif action == "d":
            _do_data(project)
        elif action == "e":
            open_explorer(project.path)
        elif action in ("b", "k"):
            open_shell(project.path)
        elif action == "p":
            open_powershell(project.path)
        elif action == "f":
            _do_full_init(project, args)
        elif action == "g":
            _do_git_init(project, args)
        elif action == "t":
            _do_template_init(project)
        elif action == "z":
            _do_zip_export(project, config, args)
        elif action == "r":
            _do_remote_status(project, args)


def _direct_start(config: Config, args: argparse.Namespace) -> int:
    """Start a specific project from CLI args."""
    matches = find_project(args.project, config)
    if not matches:
        print_error(f"Projekt nicht gefunden: {args.project}")
        return 1
    if len(matches) > 1:
        console.print(f"\n  '{args.project}' existiert in mehreren Locations:")
        for i, m in enumerate(matches, 1):
            console.print(f"    {i}. {m.path}")
        choice = ask_text(f"Welches? (1-{len(matches)})")
        try:
            project = matches[int(choice) - 1]
        except (ValueError, IndexError):
            print_error("Ungueltige Auswahl.")
            return 1
    else:
        project = matches[0]

    if hasattr(args, "resume") and args.resume:
        launch_claude(project.path, config.wsl.distro, resume=True)
        print_success(f"Claude Code gestartet (resume): {project.name}")
        return 0

    if hasattr(args, "prompt") and args.prompt:
        prompts = project.location.prompts
        if args.prompt in prompts:
            launch_claude(project.path, config.wsl.distro, prompt=prompts[args.prompt])
            print_success(f"Claude Code gestartet ({args.prompt}): {project.name}")
            return 0
        else:
            print_error(f"Prompt nicht gefunden: {args.prompt}")
            return 1

    # Interactive prompt selection
    _do_start(project, config)
    return 0


def _do_start(project, config):
    """Start Claude Code for a project with prompt selection."""
    prompts = project.location.prompts
    name, text = select_prompt(prompts)

    if name == "quit":
        return
    if name == "resume":
        launch_claude(project.path, config.wsl.distro, resume=True)
        print_success(f"Claude Code gestartet (resume): {project.name}")
    elif name == "open":
        launch_claude(project.path, config.wsl.distro)
        print_success(f"Claude Code gestartet: {project.name}")
    else:
        launch_claude(project.path, config.wsl.distro, prompt=text)
        print_success(f"Claude Code gestartet ({name}): {project.name}")


def _do_multi_start(flat_list: list, config: Config, location: Location) -> None:
    """Start Claude Code for multiple projects with prompt selection."""
    selected = select_multi_projects(flat_list)
    if not selected:
        return

    # Prompt selection — same for all projects in this location
    name, text = select_prompt(location.prompts)
    if name == "quit":
        return

    if not confirm(f"{len(selected)} Projekte mit '{name}' starten?"):
        return

    for i, project in enumerate(selected):
        if name == "resume":
            launch_claude(project.path, config.wsl.distro, resume=True)
        elif name == "open":
            launch_claude(project.path, config.wsl.distro)
        else:
            launch_claude(project.path, config.wsl.distro, prompt=text)
        print_success(f"  [{i + 1}/{len(selected)}] {project.name} gestartet ({name})")
        if i < len(selected) - 1:
            time.sleep(2.5)

    print_success(f"{len(selected)} Projekte gestartet.")


def _classify_init_gap(project) -> str:
    """Determine which init action a project needs.

    Returns one of: 'full', 'git', 'template', 'ok'.
    """
    has_template_gaps = bool(_project_template_gaps(project))
    if not project.is_git_repo and has_template_gaps:
        return "full"
    if not project.is_git_repo:
        return "git"
    if has_template_gaps:
        return "template"
    return "ok"


def _do_multi_init(flat_list: list, args=None) -> None:
    """Bulk-init for multiple projects.

    Snapshots the selected projects (gap classification taken once at
    range-entry time) and processes them sequentially. The TUI does not
    re-render the list during the operation, so devstate changes don't
    reorder anything.

    After all local-inits are done, the projects that ended up with a
    remote configured are pushed in a single spawned window via
    launch_push -- one window for the whole batch, sequential inside.
    """
    selected = select_multi_projects(flat_list)
    if not selected:
        return

    snapshot = [(p, _classify_init_gap(p)) for p in selected]
    needs_init = [(p, kind) for p, kind in snapshot if kind != "ok"]
    already_ok = len(snapshot) - len(needs_init)

    console.print(
        f"\n  [bold]Multi-Init: {len(snapshot)} ausgewaehlt[/] "
        f"({len(needs_init)} mit Luecken, {already_ok} bereits OK)"
    )
    for project, kind in snapshot:
        console.print(f"    [dim]{project.name}[/]: {kind}")

    if not needs_init:
        print_warning("Nichts zu initialisieren — alle Projekte sind komplett.")
        return

    if not confirm(f"{len(needs_init)} Projekte initialisieren?"):
        return

    failures: list[tuple[str, str]] = []
    push_pending: list = []  # ProjectInfo objects whose initial push is fällig

    for i, (project, kind) in enumerate(snapshot, start=1):
        prefix = f"  [{i}/{len(snapshot)}] {project.name}"
        if kind == "ok":
            console.print(f"{prefix}: [dim]uebersprungen (OK)[/]")
            continue

        try:
            if kind == "full":
                git_ok, copied, skipped = init_full(project.path, project.location)
                if git_ok:
                    project.is_git_repo = True
                    fetch_git_info(project)
                    if has_remote(project.path) and has_commits(project.path):
                        push_pending.append(project)
                console.print(
                    f"{prefix}: [yellow]full[/] → "
                    f"{len(copied)} kopiert, {len(skipped)} uebersprungen, "
                    f"git={'ok' if git_ok else 'FEHLER'}"
                )
                if not git_ok:
                    failures.append((project.name, "git init failed"))
            elif kind == "git":
                git_ok = init_git(project.path, project.location)
                if git_ok:
                    project.is_git_repo = True
                    fetch_git_info(project)
                    if has_remote(project.path) and has_commits(project.path):
                        push_pending.append(project)
                    console.print(f"{prefix}: [yellow]git[/] → ok")
                else:
                    console.print(f"{prefix}: [yellow]git[/] → [red]FEHLER[/]")
                    failures.append((project.name, "git init failed"))
            elif kind == "template":
                result = init_template(project.path, project.location)
                if result is None:
                    console.print(
                        f"{prefix}: [yellow]template[/] → [dim]kein Template[/]"
                    )
                    continue
                copied, skipped = result
                console.print(
                    f"{prefix}: [yellow]template[/] → "
                    f"{len(copied)} kopiert, {len(skipped)} uebersprungen"
                )
        except Exception as exc:  # noqa: BLE001
            console.print(f"{prefix}: [red]EXCEPTION[/] {exc}")
            failures.append((project.name, str(exc)))

    if failures:
        console.print("\n  [red]Fehler bei:[/]")
        for name, reason in failures:
            console.print(f"    {name}: {reason}")
    else:
        print_success(f"Multi-Init fertig: {len(needs_init)} Projekte verarbeitet.")

    # Spawn one push window for all newly-initialized repos with a remote.
    if push_pending:
        config_path = args.config if args is not None else None
        paths = [p.path for p in push_pending]
        if launch_push(paths, config_path):
            print_success(
                f"Push-Fenster gestartet: {len(push_pending)} Projekt(e) sequenziell."
            )
        else:
            print_error("Push-Fenster konnte nicht gestartet werden.")


def _do_multi_zip(flat_list: list, config: Config, args) -> None:
    """Bulk-zip-export: spawns one terminal window with `wsm export <paths...>`.

    Preflight (export_path + 7z) runs in the foreground so the user sees the
    error before the range prompt. The actual packing happens in the spawned
    window, sequentially.
    """
    from wsm.export import preflight, ExportError
    from wsm.launcher import launch_export

    try:
        preflight(config)
    except ExportError as exc:
        print_error(str(exc))
        return

    selected = select_multi_projects(flat_list)
    if not selected:
        return

    # Snapshot the path list — the export window operates on this fixed
    # ordering regardless of any later list refresh.
    paths = [p.path for p in selected]

    if not confirm(f"{len(paths)} Projekte als 7z exportieren?"):
        return

    config_path = args.config or None
    if launch_export(paths, config_path):
        print_success(
            f"Export-Fenster gestartet: {len(paths)} Projekt(e) sequenziell."
        )
    else:
        print_error("Export-Fenster konnte nicht gestartet werden.")



def _format_git_annotation(remotes: list) -> str | None:
    """Build the git-status part of a [D] annotation.

    remotes is the list returned by fetch_remote_status. Returns 'aktuell',
    '5 voraus', '3 zurueck', '5 voraus, 3 zurueck', 'kein Remote', or None
    if no annotation should be shown.
    """
    if not remotes:
        return "kein Remote"
    # Pick the most relevant remote: ahead first, then behind, else first
    for r in remotes:
        if r["ahead"] > 0:
            ahead = r["ahead"]
            behind = r["behind"]
            if behind > 0:
                return f"{ahead} voraus, {behind} zurueck"
            return f"{ahead} voraus"
    for r in remotes:
        if r["behind"] > 0:
            return f"{r['behind']} zurueck"
    return "aktuell"


def _format_template_annotation(project) -> str | None:
    """Build the template-status part of a [D] annotation.

    Returns 'Template ok', 'Template-Lücken: N', 'Template fehlt', or None
    if the location has no template configured at all.
    """
    template_path = _resolve_template_path(project.location)
    if template_path is None:
        return None
    gaps = compute_template_gaps(project.path, template_path)
    if not gaps:
        return "Template ok"
    # Count actual files in the template (skip dot-paths) for "fehlt komplett"
    total_files = 0
    for entry in template_path.rglob("*"):
        rel = entry.relative_to(template_path)
        if any(part.startswith(".") for part in rel.parts):
            continue
        total_files += 1
    if len(gaps) >= total_files and total_files > 0:
        return "Template fehlt"
    # Count only file-gaps (directories aren't "missing files" semantically)
    file_gap_count = sum(
        1 for g in gaps
        if (template_path / g).is_file()
    )
    return f"Template-Lücken: {file_gap_count}"


def compute_project_annotation(project) -> str:
    """Build the [D] Details annotation for a single project.

    Combines git status (only if is_git_repo) and template status
    (only if location has a template) into a single string. Separator
    between git and template parts is ';'; between voraus/zurueck it's ','.
    """
    parts: list[str] = []
    if project.is_git_repo:
        remotes = fetch_remote_status(project.path)
        git_part = _format_git_annotation(remotes)
        if git_part:
            parts.append(git_part)
        template_part = _format_template_annotation(project)
        if template_part:
            parts.append(template_part)
    else:
        # No git repo -> only template status (caller already shows the
        # 'kein Git-Repo' devstate category, no need to duplicate that).
        template_part = _format_template_annotation(project)
        if template_part:
            parts.append(template_part)
    return "; ".join(parts)


def compute_details_map(flat_list: list) -> dict:
    """Build {project.path -> annotation} for the [D] Details view.

    Read-only: fetches each git project's tracking ref state and walks
    each location's template directory. No mutation of the working tree.

    Caller is expected to render the list with this map as the
    `annotations` parameter on the next iteration. The map applies to
    exactly one render -- see _cmd_start's loop, where it is cleared
    immediately after each print_project_list call.
    """
    annotations: dict = {}
    for p in flat_list:
        console.print(f"  Pruefe {p.name} ...", end="\r")
        annotations[p.path] = compute_project_annotation(p)
    return annotations


def _classify_push_status(project) -> tuple[str, str]:
    """Return (status, reason) for a project relative to its remote.

    status one of: 'pushable', 'skip'.
    reason: short human-readable label for the UI.
    """
    if not project.is_git_repo:
        return "skip", "kein Git"
    remotes = fetch_remote_status(project.path)
    if not remotes:
        return "skip", "kein Remote"
    # Pick the most relevant remote: first one with ahead>0, else first
    for r in remotes:
        if r["ahead"] > 0:
            return "pushable", f"{r['ahead']} voraus"
    # No ahead anywhere: classify the first remote's state
    r = remotes[0]
    if r["behind"] > 0 and r["ahead"] == 0:
        return "skip", f"{r['behind']} zurueck"
    return "skip", "aktuell"


def _do_remote_check_all(flat_list: list, args=None) -> None:
    """Multi-Push: range-pick projects, classify, spawn push window.

    Flow:
      1. Fetch + status per project (slow, but the user typed [R] to see this)
      2. Show a status line per project so the user can pick informedly
      3. Range entry (analog Multi-Init / Multi-Zip)
      4. Snapshot the selection, classify into pushable / skip
      5. Single confirm with stats
      6. launch_push for the pushable subset -- separate window, sequential

    args.config is forwarded to the spawned subprocess so it uses the same
    config file as the main process.
    """
    if not flat_list:
        print_warning("Keine Projekte in dieser Location.")
        return

    console.print(
        f"\n  [bold]Multi-Push: {len(flat_list)} Projekt(e) werden geprueft[/]"
    )

    # Phase 1: fetch + classify for every project (this is the slow part).
    statuses: list[tuple] = []  # list of (project, status, reason)
    annotations: dict = {}
    for p in flat_list:
        console.print(f"  Pruefe {p.name} ...", end="\r")
        status, reason = _classify_push_status(p)
        statuses.append((p, status, reason))
        annotations[p.path] = reason

    # Phase 2: render the regular numbered project list with reasons as
    # annotations -- this gives the user indices for the range entry below.
    grouped = group_projects(flat_list)
    print_project_list(grouped, "", annotations=annotations)

    pushable_count = sum(1 for _, s, _ in statuses if s == "pushable")
    if pushable_count == 0:
        console.print("\n  [green]Nichts zu pushen — alles aktuell.[/]\n")
        return

    # Phase 3: range entry. Same pattern as Multi-Init.
    console.print(
        f"  [bold]{pushable_count} Projekt(e) sind voraus.[/] "
        "Welche pushen?"
    )
    selected = select_multi_projects(flat_list)
    if not selected:
        return

    # Phase 3: snapshot + classify the selection.
    status_by_path = {p.path: (s, r) for (p, s, r) in statuses}
    snapshot = []
    for p in selected:
        s, r = status_by_path.get(p.path, ("skip", "?"))
        snapshot.append((p, s, r))

    pushable = [(p, r) for (p, s, r) in snapshot if s == "pushable"]
    skipped = [(p, r) for (p, s, r) in snapshot if s == "skip"]

    console.print(
        f"\n  [bold]Auswahl: {len(snapshot)} Projekt(e)[/] "
        f"({len(pushable)} pushbar, {len(skipped)} uebersprungen)"
    )
    for p, s, r in snapshot:
        marker = "[cyan]→ wird gepusht[/]" if s == "pushable" else "[dim]→ uebersprungen[/]"
        console.print(f"    {p.name}: {r}  {marker}")

    if not pushable:
        print_warning("Keines der ausgewaehlten Projekte ist voraus — Aktion abgebrochen.")
        return

    if not confirm(f"{len(pushable)} Projekt(e) pushen?"):
        return

    # Phase 4: spawn push window. Snapshot order is preserved.
    paths = [p.path for p, _ in pushable]
    config_path = args.config if args is not None else None
    if launch_push(paths, config_path):
        print_success(
            f"Push-Fenster gestartet: {len(pushable)} Projekt(e) sequenziell."
        )
    else:
        print_error("Push-Fenster konnte nicht gestartet werden.")


def _do_clipboard_data(project, move: bool):
    """Copy or import files from clipboard into project's raw/."""
    paths = _read_paths()
    if not paths:
        return

    raw_dir = project.path / "raw"
    existing = [p for p in paths if (raw_dir / p.name).exists()]
    new = [p for p in paths if not (raw_dir / p.name).exists()]

    action_name = "Importieren (verschieben)" if move else "Kopieren"
    console.print(f"\n  [bold]{action_name}:[/]")
    print_clipboard_preview(existing, new)

    if not confirm(f"{len(paths)} Dateien/Ordner {action_name.lower()}?"):
        return

    copied = copy_files_to_raw(paths, project.path, move=move)
    print_success(f"{len(copied)} Dateien verarbeitet.")


def _do_link(project):
    """Link clipboard sources into doc-sources.yml."""
    paths = _read_paths()
    if not paths:
        return

    _, dirs = classify_clipboard_paths(paths)

    if not dirs:
        print_warning("Keine Ordner in der Zwischenablage.")
        return

    doc_sources = load_doc_sources(project.path)
    existing_names = {s.name for s in doc_sources.sources}
    new_sources: list[Source] = []

    for d in dirs:
        suggested = sanitize_name(d.name)
        name = ask_text(f"Name fuer '{d.name}'", default=suggested)
        if name in existing_names:
            print_warning(f"'{name}' existiert bereits - ueberspringe.")
            continue
        new_sources.append(Source(name=name, path=d))

    if not new_sources:
        print_warning("Keine neuen Quellen zum Verlinken.")
        return

    console.print(f"\n  [bold]Neue Eintraege fuer doc-sources.yml:[/]")
    for s in new_sources:
        console.print(f"    + {s.name}: {s.path}")

    if not confirm(f"{len(new_sources)} Quellen verlinken?"):
        return

    doc_sources.sources.extend(new_sources)
    save_doc_sources(project.path, doc_sources)
    print_success("doc-sources.yml aktualisiert.")


def _do_sync(project, config, args):
    """Launch background sync for the current project."""
    config_path = args.config or None
    if launch_sync(project.name, config_path):
        print_success(f"Sync gestartet in separatem Fenster: {project.name}")
    else:
        print_warning("Sync-Fenster konnte nicht geoeffnet werden.")


def _do_data(project):
    """Show detailed data overview for the current project."""
    detail = get_data_detail(project.path)
    show_project_data(project.name, detail)


def _do_git_init(project, args):
    """Initialize git for a non-git project directory.

    After local-init + remote setup, the actual push runs in its own
    window via launch_push -- see Spec §9.
    """
    if project.is_git_repo:
        print_warning("Projekt ist bereits ein Git-Repository.")
        return

    if not confirm(f"Git initialisieren fuer '{project.name}'?"):
        return

    if init_git(project.path, project.location):
        print_success(f"Git initialisiert: {project.name}")
        project.is_git_repo = True
        fetch_git_info(project)
        _maybe_launch_push(project, args)
    else:
        print_error("Git-Initialisierung fehlgeschlagen.")


def _maybe_launch_push(project, args):
    """If the project is push-ready, spawn a push window.

    Push-ready means: a remote 'origin' is configured AND the local
    repository has at least one commit. Without commits, 'git push'
    would fail with 'src refspec main does not match any' -- skip
    cleanly with a clear message instead.
    """
    if not has_remote(project.path):
        print_warning(
            "Kein Remote angelegt — Push uebersprungen. "
            "Spaeter ueber [R] Remote-Status nachholen."
        )
        return
    if not has_commits(project.path):
        print_warning(
            "Kein Initial-Commit vorhanden — Push uebersprungen. "
            "Verzeichnis war beim Init leer oder der Commit-Schritt "
            "ist fehlgeschlagen (z.B. Timeout)."
        )
        return
    config_path = args.config or None
    if launch_push([project.path], config_path):
        print_success(f"Push-Fenster gestartet: {project.name}")
    else:
        print_error("Push-Fenster konnte nicht gestartet werden.")


def _project_template_gaps(project) -> list:
    """List of relative paths missing in the project compared to its template.

    Returns an empty list if the location has no usable template.
    """
    template_path = _resolve_template_path(project.location)
    if template_path is None:
        return []
    return compute_template_gaps(project.path, template_path)


def _print_init_summary(copied: list[str], skipped: list[str]) -> None:
    """Print the per-file summary for [T]/[F] init."""
    if copied:
        console.print("  Kopiert:")
        for rel in copied:
            console.print(f"    {rel}")
    if skipped:
        console.print("  Uebersprungen (existiert):")
        for rel in skipped:
            console.print(f"    {rel}")
    if not copied and not skipped:
        console.print("  [dim](nichts zu tun)[/]")
    print_success(
        f"Fertig: {len(copied)} kopiert, {len(skipped)} uebersprungen."
    )


def _do_template_init(project):
    """Copy missing template files into an existing project."""
    if not confirm(f"Template-Init fuer '{project.name}'?"):
        return

    result = init_template(project.path, project.location)
    if result is None:
        print_warning("Kein Template fuer diese Location konfiguriert.")
        return

    copied, skipped = result
    console.print(f"\n  [bold]Template-Init: {project.name}[/]")
    _print_init_summary(copied, skipped)


def _do_zip_export(project, config: Config, args):
    """Spawn a terminal window running `wsm export <project_path>`."""
    from wsm.export import preflight, ExportError
    from wsm.launcher import launch_export

    try:
        preflight(config)
    except ExportError as exc:
        print_error(str(exc))
        return

    config_path = args.config or None
    if launch_export([project.path], config_path):
        print_success(f"Export-Fenster gestartet: {project.name}")
    else:
        print_error("Export-Fenster konnte nicht gestartet werden.")


def _do_full_init(project, args):
    """Run template init and git init in one go; spawn push window if remote ready."""
    if project.is_git_repo:
        print_warning("Projekt ist bereits ein Git-Repository.")
        return

    if not confirm(f"Full Init (Template + Git) fuer '{project.name}'?"):
        return

    git_ok, copied, skipped = init_full(project.path, project.location)

    console.print(f"\n  [bold]Full Init: {project.name}[/]")
    _print_init_summary(copied, skipped)
    if git_ok:
        print_success(f"Git initialisiert: {project.name}")
        project.is_git_repo = True
        fetch_git_info(project)
        _maybe_launch_push(project, args)
    else:
        print_error("Git-Initialisierung fehlgeschlagen.")


def _do_remote_status(project, args=None):
    """Show remote status (ahead/behind) for a git project, offer push/remote creation.

    Push is delegated to launch_push -- separate window, no timeout, no
    output mix with the TUI.
    """
    from wsm.workspace import setup_remote

    if not project.is_git_repo:
        print_warning("Kein Git-Repository.")
        return

    console.print(f"\n  [bold]Remote-Status: {project.name}[/]")
    console.print("  Hole Remote-Daten ...")

    remotes = fetch_remote_status(project.path)

    if not remotes:
        console.print("  [yellow]Keine Remotes konfiguriert.[/]")
        remote_url = project.location.git.remote_url(project.name)
        console.print(f"  Erwarteter Remote: {remote_url}")
        if confirm("Remote anlegen?"):
            if setup_remote(project.path, project.location):
                print_success("Remote angelegt.")
                config_path = args.config if args is not None else None
                if confirm("Push starten?"):
                    if launch_push([project.path], config_path):
                        print_success(f"Push-Fenster gestartet: {project.name}")
                    else:
                        print_error("Push-Fenster konnte nicht gestartet werden.")
            else:
                print_error("Remote-Anlage fehlgeschlagen.")
        console.print()
        return

    any_ahead = False
    for r in remotes:
        name = r["name"]
        url = r["url"]
        ahead = r["ahead"]
        behind = r["behind"]

        if ahead == 0 and behind == 0:
            status = "[green]aktuell[/]"
        elif ahead > 0 and behind == 0:
            status = f"[cyan]{ahead} Commit(s) voraus[/]"
        elif behind > 0 and ahead == 0:
            status = f"[yellow]{behind} Commit(s) zurueck[/]"
        else:
            status = f"[bright_yellow]{ahead} voraus, {behind} zurueck[/]"

        console.print(f"  [blue]{name}[/]: {url}")
        console.print(f"    {status}")

        if ahead > 0:
            any_ahead = True

    if any_ahead and confirm("Push starten?"):
        config_path = args.config if args is not None else None
        if launch_push([project.path], config_path):
            print_success(f"Push-Fenster gestartet: {project.name}")
        else:
            print_error("Push-Fenster konnte nicht gestartet werden.")

    console.print()


def _cmd_create(config: Config, args: argparse.Namespace, location_filter: Path | None) -> int:
    """Create command."""
    print_header("Neues Projekt anlegen")
    location = _resolve_location(config, location_filter)
    if location is None:
        return 0

    name = getattr(args, "name", None) or ask_text("Projektname")
    return _cmd_create_interactive(config, location, name, args)


def _cmd_create_interactive(
    config: Config,
    location: Location,
    name: str | None = None,
    args: argparse.Namespace | None = None,
) -> int:
    """Interactive project creation."""
    if name is None:
        name = ask_text("Projektname")
    if not name:
        print_error("Kein Name angegeben.")
        return 1

    clean = sanitize_name(name)
    remote = location.git.remote_url(clean)

    print_info("Name", clean)
    print_info("Pfad", str(location.path / clean))
    print_info("Remote", remote)
    print_info("Template", str(location.template_path))
    if location.git.create_remote == "gh":
        print_info("Remote-Erstellung", "GitHub CLI (private)")
    else:
        print_info("Remote-Erstellung", "git push (push-to-create)")

    if not confirm("Projekt anlegen?"):
        return 0

    result = create_project(name, location, dry_run=False)
    if result:
        print_success(f"Projekt angelegt: {result}")

        # Build project info via scanner (correct devstate detection)
        matches = find_project(clean, config)
        proj = matches[0] if matches else None
        if not proj:
            print_warning("Projekt wurde angelegt, konnte aber nicht gescannt werden.")
            return 0

        # Spawn the initial push in its own window if push-ready.
        if not has_remote(result):
            print_warning(
                "Kein Remote angelegt — Push uebersprungen. "
                "Spaeter ueber [R] Remote-Status nachholen."
            )
        elif not has_commits(result):
            print_warning(
                "Kein Initial-Commit vorhanden — Push uebersprungen. "
                "Template war leer oder der Commit-Schritt ist fehlgeschlagen."
            )
        else:
            config_path = args.config if args else None
            if launch_push([result], config_path):
                print_success(f"Push-Fenster gestartet: {clean}")
            else:
                print_error("Push-Fenster konnte nicht gestartet werden.")

        # Offer clipboard actions after creation
        if confirm("Dateien hinzufuegen?"):
            clipboard_paths = _read_paths()
            if clipboard_paths:
                console.print(
                    "  [green]\\[C][/] Kopieren  "
                    "[yellow]\\[I][/] Importieren  "
                    "[blue]\\[L][/] Linken  "
                    "[red]\\[Q][/] Ueberspringen"
                )
                choice = ask_text("Aktion").strip().lower()
                if choice == "c":
                    _do_clipboard_data(proj, move=False)
                elif choice == "i":
                    _do_clipboard_data(proj, move=True)
                elif choice == "l":
                    _do_link(proj)

                # Offer background sync
                if choice in ("c", "i", "l"):
                    config_path = args.config if args else None
                    if confirm("Sync im Hintergrund starten?"):
                        launch_sync(clean, config_path)
                        print_success(f"Sync gestartet: {clean}")

        # Enter project action menu
        _project_action_loop(proj, config, args)
        return 0
    else:
        print_error("Projekt konnte nicht angelegt werden.")
        return 1


def _cmd_update(config: Config, args: argparse.Namespace, location_filter: Path | None) -> int:
    """Update command: sync all sources."""
    print_header("Quellen synchronisieren")

    pool = None
    if config.docling_servers:
        workers = getattr(args, "workers", None) or config.docling_workers_per_server
        pool = DoclingPool(
            config.docling_servers,
            workers_per_server=workers,
            retry_timeout=config.docling_retry_timeout,
        )
        asyncio.run(pool.initialize())
        if pool.is_available:
            print_success("Docling-Server verfuegbar.")
        else:
            urls = ", ".join(config.docling_servers)
            print_warning(
                f"Docling-Server nicht erreichbar ({urls}). "
                "Konvertierung wird uebersprungen, nur .md-Dateien werden kopiert."
            )
    else:
        print_warning(
            "Keine Docling-Server konfiguriert "
            "(docling_servers in ~/.workspacemanager.yml ist leer). "
            "Konvertierung wird uebersprungen, nur .md-Dateien werden kopiert."
        )

    ollama_pool = None
    if config.ollama_servers:
        ollama_pool = OllamaPool(
            config.ollama_servers,
            model=config.ollama_vision_model,
            retry_timeout=config.docling_retry_timeout,
        )
        asyncio.run(ollama_pool.initialize())
        if ollama_pool.is_available:
            print_success(f"Ollama-Server verfuegbar (Modell: {config.ollama_vision_model}).")
        else:
            print_warning("Kein Ollama-Server erreichbar. Bilder werden uebersprungen.")

    total_c, total_s, total_e = 0, 0, 0
    from collections import Counter
    total_skip_reasons: Counter = Counter()

    project_name = getattr(args, "project", None)

    def _progress(
        completed_bytes: int, total_bytes: int,
        completed_files: int, remaining_files: int,
    ) -> None:
        completed_mb = completed_bytes / (1024 * 1024)
        total_mb = total_bytes / (1024 * 1024)
        pct = (completed_bytes / total_bytes * 100) if total_bytes > 0 else 0
        console.print(
            f"    {completed_mb:.1f}/{total_mb:.1f} MB ({pct:.0f}%) "
            f"— {remaining_files} Dateien verbleibend",
            highlight=False,
        )

    def _scan(source_name: str, files_found: int, total_jobs: int) -> None:
        console.print(
            f"    Quelle '{source_name}': {files_found} Dateien "
            f"({total_jobs} zu konvertieren)",
            highlight=False,
        )

    def _file_count(count: int) -> None:
        console.print(f"    {count} Dateien eingelesen...", end="\r", highlight=False)

    def _scan_complete(
        docling_count: int, image_count: int,
        passthrough_count: int, stats: object,
    ) -> None:
        console.print(
            f"    Scan abgeschlossen: {docling_count} Docling, "
            f"{image_count} Bilder, {passthrough_count} kopiert, "
            f"{stats.skipped} uebersprungen",
            highlight=False,
        )
        if stats.skip_reasons:
            for reason, count in stats.skip_reasons.most_common():
                console.print(f"      {count:>6d}  {reason}", highlight=False)

    def _run_sync(project_path: Path) -> tuple[int, int, int]:
        c, s, e, stats = asyncio.run(
            sync_project(
                project_path, pool, _progress, _scan, _file_count, ollama_pool,
                _scan_complete,
            )
        )
        total_skip_reasons.update(stats.skip_reasons)
        return c, s, e

    for location in config.locations:
        if location_filter and location.path != location_filter:
            continue

        console.print(f"\n  [bold]── {location.path} ──[/]")

        if project_name:
            project_path = location.path / project_name
            if project_path.is_dir():
                console.print(f"\n  [cyan]{project_name}[/]")
                c, s, e = _run_sync(project_path)
                print_sync_summary(project_name, c, s, e)
                total_c += c
                total_s += s
                total_e += e
        else:
            for entry in sorted(location.path.iterdir()):
                if not entry.is_dir() or entry.name == location.template:
                    continue
                if entry.name.startswith("."):
                    continue
                console.print(f"\n  [cyan]{entry.name}[/]")
                c, s, e = _run_sync(entry)
                print_sync_summary(entry.name, c, s, e)
                total_c += c
                total_s += s
                total_e += e

    console.print()
    console.print(
        f"  [bold]Gesamt:[/] {total_c} konvertiert, {total_s} uebersprungen, {total_e} Fehler"
    )
    if total_skip_reasons:
        console.print(f"\n  [bold]Uebersprungen:[/]")
        for reason, count in total_skip_reasons.most_common():
            console.print(f"    {count:>6d}  {reason}")
    return 0


def _cmd_clipboard_data(
    config: Config,
    args: argparse.Namespace,
    location_filter: Path | None,
    mode: str,
) -> int:
    """Copy or import from clipboard (standalone command)."""
    move = mode == "import"
    action_name = "Importieren" if move else "Kopieren"
    print_header(f"Dateien {action_name}")

    paths = _read_paths()
    if not paths:
        return 1

    console.print(f"  {len(paths)} Dateien/Ordner.")

    # Resolve project
    project_name = getattr(args, "project", None)
    if project_name:
        matches = find_project(project_name, config, location_filter)
        if not matches:
            print_error(f"Projekt nicht gefunden: {project_name}")
            return 1
        project = matches[0]
    else:
        location = _resolve_location(config, location_filter)
        if location is None:
            return 0
        projects = scan_location(location)
        grouped = group_projects(projects)
        flat_list = print_project_list(grouped, str(location.path))
        selection = select_project(flat_list)
        if selection is None or selection == "n":
            return 0
        project = selection

    _do_clipboard_data(project, move=move)
    return 0


def _cmd_link(config: Config, args: argparse.Namespace, location_filter: Path | None) -> int:
    """Link sources from clipboard (standalone command)."""
    print_header("Quellen verlinken")

    # Resolve project
    project_name = getattr(args, "project", None)
    if project_name:
        matches = find_project(project_name, config, location_filter)
        if not matches:
            print_error(f"Projekt nicht gefunden: {project_name}")
            return 1
        project = matches[0]
    else:
        location = _resolve_location(config, location_filter)
        if location is None:
            return 0
        projects = scan_location(location)
        grouped = group_projects(projects)
        flat_list = print_project_list(grouped, str(location.path))
        selection = select_project(flat_list)
        if selection is None or selection == "n":
            return 0
        project = selection

    _do_link(project)
    return 0


def _cmd_export(config: Config, args: argparse.Namespace) -> int:
    """Subcommand `wsm export <paths...>`. Runs in the spawned terminal window."""
    from wsm.export import run_export

    return run_export(list(args.paths), config)


def _cmd_push(args: argparse.Namespace) -> int:
    """Subcommand `wsm push <paths...>`. Runs in the spawned terminal window."""
    from wsm.push import run_push

    return run_push(list(args.paths))


def _cmd_config(args: argparse.Namespace) -> int:
    """Config management command."""
    config_path = args.config or default_config_path()

    if hasattr(args, "path") and args.path:
        console.print(str(config_path))
        return 0

    if hasattr(args, "init") and args.init:
        return _config_init(config_path)

    if hasattr(args, "edit") and args.edit:
        from wsm.platform import get_platform
        get_platform().open_editor(config_path)
        print_success(f"Editor geoeffnet: {config_path}")
        return 0

    if hasattr(args, "validate") and args.validate:
        try:
            config = load_config(config_path)
            print_success(f"Konfiguration gueltig: {config_path}")
            print_info("Locations", str(len(config.locations)))
            print_info("Docling-Server", str(len(config.docling_servers)))
            print_info("WSL-Distro", config.wsl.distro)
            return 0
        except (FileNotFoundError, ValueError) as exc:
            print_error(str(exc))
            return 1

    # Default: show config
    try:
        config = load_config(config_path)
    except FileNotFoundError:
        print_warning(f"Keine Konfiguration gefunden: {config_path}")
        print_info("Erstellen mit", "wsm config --init")
        return 1
    except ValueError as exc:
        print_error(str(exc))
        return 1

    print_header("Konfiguration")
    print_info("Datei", str(config_path))

    for i, loc in enumerate(config.locations, 1):
        console.print(f"\n  [bold]Location {i}:[/]")
        print_info("  Pfad", str(loc.path))
        print_info("  Git", f"{loc.git.url} ({loc.git.owner})")
        print_info("  Template", loc.template)
        print_info("  Remote", loc.git.create_remote)
        if loc.prompts:
            print_info("  Prompts", ", ".join(loc.prompts.keys()))

    if config.docling_servers:
        console.print(f"\n  [bold]Docling-Server:[/]")
        for s in config.docling_servers:
            console.print(f"    - {s}")

    print_info("\nWSL-Distro", config.wsl.distro)
    if config.log_file:
        print_info("Log-Datei", str(config.log_file))

    return 0


def _config_init(config_path: Path) -> int:
    """Interactive config initialization."""
    if config_path.exists():
        if not confirm(f"Config existiert bereits ({config_path}). Ueberschreiben?"):
            return 0

    print_header("Neue Konfiguration")

    locations = []
    while True:
        console.print(f"\n  [bold]Location {len(locations) + 1}:[/]")
        path = ask_text("Projektverzeichnis", default="~/source/repos")
        git_url = ask_text("Git-Server URL")
        git_user = ask_text("Git-User")
        git_name = ask_text("Git-Name (fuer Commits)")
        git_email = ask_text("Git-Email (fuer Commits)")
        create_remote = ask_text("Remote-Erstellung (gh/push)", default="push")
        template = ask_text("Template-Ordner", default="_Template")

        git_cfg = {"url": git_url, "user": git_user}
        if git_name:
            git_cfg["name"] = git_name
        if git_email:
            git_cfg["email"] = git_email
        if create_remote != "push":
            git_cfg["create_remote"] = create_remote

        locations.append({
            "path": path,
            "git": git_cfg,
            "template": template,
            "prompts": {},
        })

        if not confirm("Weitere Location hinzufuegen?"):
            break

    distro = ask_text("WSL-Distro", default="claude")

    docling_servers = []
    if confirm("Docling-Server konfigurieren?"):
        while True:
            url = ask_text("Server-URL", default="http://localhost:5001")
            docling_servers.append(url)
            if not confirm("Weiterer Server?"):
                break

    log_file = ask_text("Log-Datei", default="~/.workspacemanager.log")

    data = {
        "locations": locations,
        "wsl": {"distro": distro},
        "docling_servers": docling_servers,
        "log_file": log_file,
    }

    save_config(config_path, data)
    print_success(f"Config geschrieben: {config_path}")
    return 0


# ── Helpers ──────────────────────────────────────────────────────────


def _resolve_location(config: Config, location_filter: Path | None) -> Location | None:
    """Resolve which location to use."""
    locations = config.locations

    if location_filter:
        for loc in locations:
            if loc.path == location_filter:
                return loc
        print_error(f"Location nicht gefunden: {location_filter}")
        return None

    if len(locations) == 1:
        return locations[0]

    labels = [str(loc.path) for loc in locations]
    idx = select_location(labels)
    if idx is None:
        return None
    return locations[idx]
