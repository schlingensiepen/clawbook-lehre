"""Load and validate the user configuration from YAML."""

import logging
import os
import shutil
import subprocess
from pathlib import Path

import yaml

from wsm.models import Config, GitConfig, Location, WslConfig
from wsm.paths import expand_tilde

logger = logging.getLogger("wsm")

DEFAULT_CONFIG_FILENAME = ".workspacemanager.yml"


def default_config_path() -> Path:
    """Return the default config file path (%USERPROFILE%/.workspacemanager.yml)."""
    return expand_tilde(f"~/{DEFAULT_CONFIG_FILENAME}")


def _git_config_get(key: str) -> str | None:
    if not shutil.which("git"):
        return None
    try:
        result = subprocess.run(
            ["git", "config", "--global", key],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (subprocess.SubprocessError, OSError):
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _detect_gh_user() -> str | None:
    if not shutil.which("gh"):
        return None
    try:
        result = subprocess.run(
            ["gh", "api", "user", "--jq", ".login"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.SubprocessError, OSError):
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _build_default_config_data() -> dict:
    gh_user = _detect_gh_user()
    git_name = _git_config_get("user.name")
    git_email = _git_config_get("user.email")

    git_block: dict = {
        "url": "ssh://git@github.com",
        "create_remote": "gh",
    }
    if gh_user:
        git_block["user"] = gh_user
    if git_name:
        git_block["name"] = git_name
    if git_email:
        git_block["email"] = git_email

    if "user" not in git_block:
        default_user = (
            os.environ.get("USER") or os.environ.get("USERNAME") or ""
        )
        try:
            answer = input(
                f"GitHub-Benutzername [{default_user}]: "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            answer = ""
        git_block["user"] = answer or default_user

    return {
        "locations": [
            {
                "name": "source",
                "path": str(Path.home() / "source"),
                "git": git_block,
            }
        ],
        "wsl": {"distro": "Ubuntu"},
        "docling_servers": [],
        "ollama_servers": [],
    }


def ensure_default_config(path: Path) -> None:
    """Create a minimal valid config at *path* if it does not yet exist.

    Fills git.user from `gh api user` when gh is available; otherwise prompts
    once interactively (empty input is accepted and persisted as empty).
    """
    if path.exists():
        return
    data = _build_default_config_data()
    save_config(path, data)
    logger.info("Standard-Konfiguration angelegt: %s", path)


def load_config(config_path: Path | None = None) -> Config:
    """Load and validate the configuration file.

    Args:
        config_path: Explicit path to config file. Uses default if None.
            When the default path is used and no file exists, a minimal
            standard configuration is auto-generated.

    Returns:
        A validated Config object.

    Raises:
        FileNotFoundError: If an explicit config file does not exist.
        ValueError: If the config file is invalid.
    """
    if config_path is None:
        path = default_config_path()
        ensure_default_config(path)
    else:
        path = config_path

    if not path.exists():
        raise FileNotFoundError(
            f"Konfigurationsdatei nicht gefunden: {path}\n"
            f"Erstellen mit: wsm config --init"
        )

    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Ungueltige Konfigurationsdatei: {path}")

    return _parse_config(raw)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base* (returns a new dict).

    Nested dicts are merged recursively; scalars and lists in *override*
    replace their *base* counterparts.
    """
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _resolve_single(
    name: str,
    raw: dict,
    named: dict[str, dict],
    resolved: dict[str, dict],
    chain: set[str],
) -> dict:
    """Resolve a single location's inheritance chain.

    Args:
        name: The location name being resolved.
        raw: The raw dict for this location.
        named: Index of all named raw dicts (name → dict).
        resolved: Cache of already-resolved dicts.
        chain: Set of names currently being resolved (cycle detection).

    Returns:
        The fully-merged raw dict (without ``based_on``).
    """
    if name in resolved:
        return resolved[name]

    if name in chain:
        raise ValueError(f"Config: Zirkulaere Referenz bei Location '{name}'.")
    chain.add(name)

    parent_name = raw.get("based_on")
    if parent_name is None:
        # No inheritance – just cache and return a copy.
        merged = {k: v for k, v in raw.items()}
        resolved[name] = merged
        return merged

    if parent_name not in named:
        raise ValueError(
            f"Config: Location '{name}' referenziert unbekannte Location '{parent_name}'."
        )

    parent_raw = named[parent_name]
    parent_merged = _resolve_single(parent_name, parent_raw, named, resolved, chain)

    merged = _deep_merge(parent_merged, raw)
    merged.pop("based_on", None)

    # Template inheritance: if the child did NOT specify its own 'template',
    # resolve it absolutely against the parent's path. This lets sub-locations
    # reuse the parent's template directory (e.g. ~/source/repos/_Template)
    # instead of expecting a local _Template/ in every child path.
    if "template" in raw:
        # Child set its own template -> drop any inherited override so the
        # template is resolved relative to the child's own path.
        merged.pop("_template_path_override", None)
    else:
        # Child inherited 'template' from the parent (or doesn't have one).
        if "_template_path_override" in parent_merged:
            # Parent already has an absolute override (grandparent inherited)
            # -- _deep_merge has propagated it; nothing to do.
            pass
        elif parent_merged.get("template"):
            parent_path = expand_tilde(parent_merged["path"])
            merged["_template_path_override"] = str(
                parent_path / parent_merged["template"]
            )

    resolved[name] = merged
    return merged


def _resolve_locations(raw_locations: list[dict]) -> list[Location]:
    """Resolve ``based_on`` inheritance and return parsed Location objects.

    Two-pass approach:
      1. Build an index of ``name → raw_dict`` (detect duplicates).
      2. Resolve each location (following ``based_on`` chains) and parse.
    """
    # --- Pass 1: index named locations ---
    named: dict[str, dict] = {}
    for loc in raw_locations:
        loc_name = loc.get("name")
        if loc_name:
            if loc_name in named:
                raise ValueError(f"Config: Doppelter Location-Name '{loc_name}'.")
            named[loc_name] = loc

    # --- Validate based_on entries require own path ---
    for loc in raw_locations:
        if "based_on" in loc and "path" not in loc:
            ref = loc.get("name", loc.get("based_on", "?"))
            raise ValueError(
                f"Config: Location '{ref}' mit 'based_on' braucht einen eigenen 'path'."
            )

    # --- Pass 2: resolve and parse ---
    resolved: dict[str, dict] = {}
    result: list[Location] = []
    for loc in raw_locations:
        loc_name = loc.get("name")
        if loc_name and "based_on" in loc:
            merged = _resolve_single(loc_name, loc, named, resolved, set())
            result.append(_parse_location(merged))
        elif loc_name and loc_name not in resolved:
            # Named but no based_on – resolve for potential children, then parse.
            _resolve_single(loc_name, loc, named, resolved, set())
            result.append(_parse_location(resolved[loc_name]))
        elif loc_name:
            result.append(_parse_location(resolved[loc_name]))
        else:
            result.append(_parse_location(loc))
    return result


def _parse_config(raw: dict) -> Config:
    """Parse raw YAML dict into a Config object."""
    # Locations (required)
    raw_locations = raw.get("locations")
    if not raw_locations or not isinstance(raw_locations, list):
        raise ValueError("Config: 'locations' muss eine nicht-leere Liste sein.")

    locations = _resolve_locations(raw_locations)

    # WSL config
    raw_wsl = raw.get("wsl", {})
    wsl = WslConfig(distro=raw_wsl.get("distro", "Ubuntu"))

    # Docling servers
    docling_servers = raw.get("docling_servers", [])
    if not isinstance(docling_servers, list):
        raise ValueError("Config: 'docling_servers' muss eine Liste sein.")

    # Docling workers per server
    docling_workers_per_server = raw.get("docling_workers_per_server", 2)
    if not isinstance(docling_workers_per_server, int) or docling_workers_per_server < 1:
        raise ValueError(
            "Config: 'docling_workers_per_server' muss eine positive Ganzzahl sein."
        )

    # Docling retry timeout
    docling_retry_timeout = raw.get("docling_retry_timeout", 180)
    if not isinstance(docling_retry_timeout, int) or docling_retry_timeout < 0:
        raise ValueError(
            "Config: 'docling_retry_timeout' muss eine nicht-negative Ganzzahl sein."
        )

    # Ollama servers
    ollama_servers = raw.get("ollama_servers", [])
    if not isinstance(ollama_servers, list):
        raise ValueError("Config: 'ollama_servers' muss eine Liste sein.")

    # Ollama vision model
    ollama_vision_model = raw.get("ollama_vision_model", "llava")
    if not isinstance(ollama_vision_model, str) or not ollama_vision_model:
        raise ValueError("Config: 'ollama_vision_model' muss ein nicht-leerer String sein.")

    # Log file
    raw_log = raw.get("log_file")
    log_file = expand_tilde(raw_log) if raw_log else None

    # Export
    raw_export = raw.get("export_path")
    export_path = expand_tilde(raw_export) if raw_export else None
    raw_7z = raw.get("sevenzip_path")
    sevenzip_path = expand_tilde(raw_7z) if raw_7z else None

    return Config(
        locations=locations,
        wsl=wsl,
        docling_servers=docling_servers,
        docling_workers_per_server=docling_workers_per_server,
        docling_retry_timeout=docling_retry_timeout,
        ollama_servers=ollama_servers,
        ollama_vision_model=ollama_vision_model,
        log_file=log_file,
        export_path=export_path,
        sevenzip_path=sevenzip_path,
    )


def _parse_location(raw: dict) -> Location:
    """Parse a single location entry."""
    if not isinstance(raw, dict):
        raise ValueError("Config: Jede Location muss ein Dictionary sein.")

    raw_path = raw.get("path")
    if not raw_path:
        raise ValueError("Config: Jede Location braucht einen 'path'.")

    # Git config (required)
    raw_git = raw.get("git")
    if not isinstance(raw_git, dict):
        raise ValueError(f"Config: Location '{raw_path}' braucht eine 'git' Konfiguration.")

    git_url = raw_git.get("url")
    git_user = raw_git.get("user", "")
    git_org = raw_git.get("org", "")
    if not git_url:
        raise ValueError(f"Config: Location '{raw_path}': git.url ist Pflicht.")
    if not git_user and not git_org:
        raise ValueError(
            f"Config: Location '{raw_path}': git.user oder git.org ist Pflicht."
        )

    git_name = raw_git.get("name", "")
    git_email = raw_git.get("email", "")

    create_remote = raw_git.get("create_remote", "push")
    if create_remote not in ("push", "gh"):
        raise ValueError(
            f"Config: Location '{raw_path}': git.create_remote muss 'push' oder 'gh' sein."
        )

    git = GitConfig(
        url=git_url.rstrip("/"),
        user=git_user,
        org=git_org,
        name=git_name,
        email=git_email,
        create_remote=create_remote,
    )

    # Optional fields
    template = raw.get("template", "")
    prompts = raw.get("prompts", {})
    if not isinstance(prompts, dict):
        raise ValueError(f"Config: Location '{raw_path}': 'prompts' muss ein Dictionary sein.")

    name = raw.get("name", "")

    # Set by _resolve_single during based_on inheritance when the child
    # had no own 'template' key. None on plain (non-inherited) locations.
    raw_override = raw.get("_template_path_override")
    template_path_override = Path(raw_override) if raw_override else None

    return Location(
        path=expand_tilde(raw_path),
        git=git,
        template=template,
        prompts=prompts,
        name=name,
        _template_path_override=template_path_override,
    )


def save_config(config_path: Path, data: dict) -> None:
    """Write a config dict as YAML to the given path."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    logger.info("Config geschrieben: %s", config_path)
