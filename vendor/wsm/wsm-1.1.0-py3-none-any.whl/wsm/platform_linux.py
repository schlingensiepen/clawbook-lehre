"""Linux platform backend: tmux sessions, xdg-open, xclip."""

import logging
import os
import shutil
import subprocess
from pathlib import Path

from wsm.paths import sanitize_name
from wsm.platform_base import PlatformBackend
from wsm.utils import random_dark_color

logger = logging.getLogger("wsm")

# tmux options applied to every new session:
# -u: enable UTF-8 (umlauts, special characters)
# set-option mouse on: enable mouse wheel scrolling
TMUX_BASE_CMD = ["tmux", "-u"]
TMUX_MOUSE_SET = "set-option -g mouse on"


def _tmux_session_exists(name: str) -> bool:
    """Check if a tmux session with the given name already exists."""
    result = subprocess.run(
        [*TMUX_BASE_CMD, "has-session", "-t", name],
        capture_output=True,
        timeout=5,
    )
    return result.returncode == 0


def _unique_session_name(base: str) -> str:
    """Return a unique tmux session name, appending a counter if needed."""
    if not _tmux_session_exists(base):
        return base
    for i in range(2, 100):
        candidate = f"{base}-{i}"
        if not _tmux_session_exists(candidate):
            return candidate
    return f"{base}-{os.getpid()}"


class LinuxBackend(PlatformBackend):
    """Linux implementation using tmux, xdg-open, and xclip."""

    def launch_claude(
        self,
        project_path: Path,
        distro: str,
        prompt: str | None = None,
        resume: bool = False,
    ) -> bool:
        if not shutil.which("tmux"):
            logger.warning("tmux nicht gefunden. Bitte installieren: sudo apt install tmux")
            return False

        project_name = project_path.name

        if resume:
            claude_cmd = "claude --resume"
        elif prompt:
            clean = " ".join(prompt.split())
            escaped = clean.replace("'", "'\\''")
            claude_cmd = f"claude '{escaped}'"
        else:
            claude_cmd = "claude"

        bg_color = random_dark_color()
        set_bg = f"echo -e '\\e]11;{bg_color}\\a'"
        bash_cmd = (
            f"{set_bg}; cd '{project_path}' && {claude_cmd}; "
            f"echo; read -p 'Enter zum Schliessen...'"
        )

        session = _unique_session_name(f"claude-{sanitize_name(project_name)}")

        try:
            subprocess.run(
                [*TMUX_BASE_CMD, "new-session", "-d", "-s", session,
                 f"bash -c \"{bash_cmd}\""],
                check=False,
                timeout=10,
            )
            subprocess.run(
                [*TMUX_BASE_CMD, "set-option", "-t", session, "mouse", "on"],
                capture_output=True,
                timeout=5,
            )
            logger.info("tmux-Session gestartet: %s", session)
            print(f"  > tmux attach -t {session}")
            return True
        except OSError as exc:
            logger.warning("tmux-Session konnte nicht gestartet werden: %s", exc)
            return False

    def launch_sync(
        self,
        project_name: str | None = None,
        config_path: Path | None = None,
    ) -> bool:
        if not shutil.which("tmux"):
            logger.warning("tmux nicht gefunden. Bitte installieren: sudo apt install tmux")
            return False

        wsm_parts = ["wsm"]
        if config_path:
            wsm_parts.extend(["--config", str(config_path)])
        wsm_parts.append("update")
        if project_name:
            wsm_parts.append(project_name)
        wsm_cmd = " ".join(wsm_parts)

        bash_cmd = f"{wsm_cmd}; echo; read -p 'Enter zum Schliessen...'"
        label = sanitize_name(project_name) if project_name else "alle"
        session = _unique_session_name(f"sync-{label}")

        try:
            subprocess.run(
                [*TMUX_BASE_CMD, "new-session", "-d", "-s", session,
                 f"bash -c \"{bash_cmd}\""],
                check=False,
                timeout=10,
            )
            subprocess.run(
                [*TMUX_BASE_CMD, "set-option", "-t", session, "mouse", "on"],
                capture_output=True,
                timeout=5,
            )
            logger.info("Sync-Session gestartet: %s", session)
            print(f"  > tmux attach -t {session}")
            return True
        except OSError as exc:
            logger.warning("Sync-Session konnte nicht gestartet werden: %s", exc)
            return False

    def launch_export(
        self,
        project_paths: list[Path],
        config_path: Path | None = None,
    ) -> bool:
        return self._launch_subcommand(
            subcommand="export",
            project_paths=project_paths,
            config_path=config_path,
            session_prefix="export",
        )

    def launch_push(
        self,
        project_paths: list[Path],
        config_path: Path | None = None,
    ) -> bool:
        return self._launch_subcommand(
            subcommand="push",
            project_paths=project_paths,
            config_path=config_path,
            session_prefix="push",
        )

    def _launch_subcommand(
        self,
        subcommand: str,
        project_paths: list[Path],
        config_path: Path | None,
        session_prefix: str,
    ) -> bool:
        """Shared spawner for export/push: opens a detached tmux session
        running 'wsm <sub> <paths...>'.

        Single-quote each path for the bash invocation. Single-quotes in
        filenames are extremely rare and we don't try to handle them.
        """
        if not project_paths:
            return False
        if not shutil.which("tmux"):
            logger.warning("tmux nicht gefunden. Bitte installieren: sudo apt install tmux")
            return False

        wsm_parts = ["wsm"]
        if config_path:
            wsm_parts.extend(["--config", f"'{config_path}'"])
        wsm_parts.append(subcommand)
        for path in project_paths:
            wsm_parts.append(f"'{path}'")
        wsm_cmd = " ".join(wsm_parts)

        bash_cmd = f"{wsm_cmd}; echo; read -p 'Enter zum Schliessen...'"
        if len(project_paths) == 1:
            label = sanitize_name(project_paths[0].name)
        else:
            label = f"{len(project_paths)}-projekte"
        session = _unique_session_name(f"{session_prefix}-{label}")

        try:
            subprocess.run(
                [*TMUX_BASE_CMD, "new-session", "-d", "-s", session,
                 f"bash -c \"{bash_cmd}\""],
                check=False,
                timeout=10,
            )
            subprocess.run(
                [*TMUX_BASE_CMD, "set-option", "-t", session, "mouse", "on"],
                capture_output=True,
                timeout=5,
            )
            logger.info("%s-Session gestartet: %s", session_prefix, session)
            print(f"  > tmux attach -t {session}")
            return True
        except OSError as exc:
            logger.warning("%s-Session konnte nicht gestartet werden: %s",
                           session_prefix, exc)
            return False

    def open_explorer(self, project_path: Path) -> bool:
        if not shutil.which("xdg-open"):
            logger.warning(
                "xdg-open nicht verfuegbar (z. B. im Container). Projekt: %s",
                project_path,
            )
            return False
        try:
            subprocess.Popen(["xdg-open", str(project_path)])
            logger.info("Dateimanager geoeffnet: %s", project_path)
            return True
        except OSError as exc:
            logger.warning(
                "Dateimanager konnte nicht geoeffnet werden: %s. Projekt: %s",
                exc, project_path,
            )
            return False

    def open_shell(self, project_path: Path) -> bool:
        session = _unique_session_name(f"shell-{sanitize_name(project_path.name)}")
        try:
            # Foreground: blocks wsm until user types 'exit'
            subprocess.run(
                [*TMUX_BASE_CMD, "new-session", "-s", session, "-c", str(project_path)],
                check=False,
            )
            logger.info("Shell-Session beendet: %s", session)
            return True
        except FileNotFoundError:
            # No tmux — fall back to direct subshell
            shell = os.environ.get("SHELL", "/bin/bash")
            subprocess.run([shell], cwd=project_path, check=False)
            return True
        except OSError as exc:
            logger.warning("Shell konnte nicht geoeffnet werden: %s", exc)
            return False

    def open_powershell(self, project_path: Path) -> bool:
        pwsh = shutil.which("pwsh")
        if pwsh:
            session = _unique_session_name(f"pwsh-{sanitize_name(project_path.name)}")
            try:
                subprocess.run(
                    [*TMUX_BASE_CMD, "new-session", "-s", session, "-c", str(project_path),
                     pwsh],
                    check=False,
                )
                logger.info("PowerShell-Session beendet: %s", session)
                return True
            except FileNotFoundError:
                subprocess.run([pwsh], cwd=project_path, check=False)
                return True
        else:
            logger.warning(
                "pwsh nicht gefunden. "
                "Bitte installieren: https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-linux"
            )
            # Fall back to regular shell
            return self.open_shell(project_path)

    def open_editor(self, file_path: Path) -> bool:
        editor = os.environ.get("EDITOR", "xdg-open")
        try:
            subprocess.Popen([editor, str(file_path)])
            logger.info("Editor geoeffnet (%s): %s", editor, file_path)
            return True
        except OSError as exc:
            logger.warning("Editor konnte nicht geoeffnet werden: %s", exc)
            return False

    def read_clipboard_paths(self) -> list[Path]:
        # Try xclip first, then xsel
        for tool, args in [
            ("xclip", ["xclip", "-selection", "clipboard", "-o"]),
            ("xsel", ["xsel", "--clipboard", "--output"]),
        ]:
            if not shutil.which(tool):
                continue
            try:
                result = subprocess.run(
                    args,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode != 0:
                    continue
                lines = result.stdout.strip().splitlines()
                paths = []
                for line in lines:
                    line = line.strip()
                    if line:
                        p = Path(line)
                        if p.exists():
                            paths.append(p)
                return paths
            except (subprocess.TimeoutExpired, OSError):
                continue

        logger.warning(
            "Kein Clipboard-Tool verfuegbar (xclip/xsel). "
            "Im Container oder ohne X-Display nicht nutzbar — "
            "Dateien stattdessen manuell nach raw/ ablegen."
        )
        return []

    def restore_console(self) -> None:
        pass  # not needed on Linux
