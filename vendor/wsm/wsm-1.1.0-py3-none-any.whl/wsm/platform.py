"""Platform detection and singleton backend access."""

import sys
from functools import lru_cache

from wsm.platform_base import PlatformBackend


@lru_cache(maxsize=1)
def get_platform() -> PlatformBackend:
    """Return the platform backend (detected once, cached).

    Windows: WindowsBackend (cmd.exe, WSL, PowerShell clipboard).
    Linux: LinuxBackend (tmux, xdg-open, xclip).
    """
    if sys.platform == "win32":
        from wsm.platform_windows import WindowsBackend

        return WindowsBackend()
    else:
        from wsm.platform_linux import LinuxBackend

        return LinuxBackend()
