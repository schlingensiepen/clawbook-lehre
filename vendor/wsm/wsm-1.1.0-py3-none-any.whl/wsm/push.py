"""Initial-push subcommand: 'wsm push <pfad...>'.

Runs in the spawned terminal window after wsm has set up local-init +
remote. Pushes each path sequentially with no timeout, so large repos
can take their time without the parent process being blocked.

UNC-safety: subprocess.run with cwd=str(path) and explicit args, no
shell=True with cd indirection.
"""

from __future__ import annotations

import logging
import subprocess
import sys
from pathlib import Path

from wsm.scanner import git_run

logger = logging.getLogger("wsm")


def _has_upstream(project_path: Path) -> bool:
    """True if the current branch has an upstream tracking ref.

    Runs 'git rev-parse --abbrev-ref @{u}' -- exits 0 with the upstream
    name (e.g. 'origin/main') if set, non-zero otherwise.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "@{u}"],
            cwd=str(project_path),
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def _current_branch(project_path: Path) -> str | None:
    """Return the name of the currently checked-out branch, or None."""
    try:
        result = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=str(project_path),
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    name = result.stdout.strip()
    return name or None


def push_one(project_path: Path) -> tuple[bool, str]:
    """Push the current branch. Returns (ok, message).

    Auto-detects whether an upstream is set:
      - upstream set  -> 'git push'  (uses the configured upstream)
      - no upstream   -> 'git push -u origin <current-branch>'

    No timeout -- the user can Ctrl+C if it hangs. Output goes straight to
    the parent (this subprocess's) stdout/stderr so the user watches it
    live in the spawned window.
    """
    if not project_path.exists() or not project_path.is_dir():
        return False, f"Pfad existiert nicht: {project_path}"

    git_dir = project_path / ".git"
    if not git_dir.exists():
        return False, f"Kein Git-Repo: {project_path}"

    if _has_upstream(project_path):
        args = ["git", "push"]
    else:
        branch = _current_branch(project_path) or "main"
        args = ["git", "push", "-u", "origin", branch]
        print(f"  (kein Upstream gesetzt — initialer Push: {' '.join(args[2:])})")

    try:
        result = subprocess.run(
            args,
            cwd=str(project_path),
            text=True,
        )
    except OSError as exc:
        return False, f"git konnte nicht gestartet werden: {exc}"

    if result.returncode != 0:
        return False, f"git push exit code {result.returncode}"
    return True, "ok"


def run_push(paths: list[Path]) -> int:
    """CLI entry point. Push each path sequentially.

    Returns 0 on all-success, 1 if any push failed.
    """
    if not paths:
        print("Keine Pfade angegeben.", file=sys.stderr)
        return 1

    n = len(paths)
    failures: list[tuple[Path, str]] = []

    for i, path in enumerate(paths, start=1):
        print(f"\n[{i}/{n}] {path.name}: pushe ...")
        ok, message = push_one(path)
        if ok:
            print(f"  -> ok")
        else:
            print(f"  -> FEHLER: {message}")
            failures.append((path, message))

    print("\nZusammenfassung:")
    print(f"  Gepusht: {n - len(failures)}/{n}")
    if failures:
        print("  Fehler:")
        for path, message in failures:
            print(f"    {path.name}: {message}")
        return 1
    return 0
