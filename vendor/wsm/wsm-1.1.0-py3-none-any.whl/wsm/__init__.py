"""Workspace Manager - manage development projects with Claude Code in WSL."""

__version__ = "1.1.0"
