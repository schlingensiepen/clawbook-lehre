"""Shared utilities used across platform backends."""

import colorsys
import random


def random_dark_color() -> str:
    """Generate a random dark background color as hex (#RRGGBB).

    Uses HSL with full hue range, moderate saturation and low lightness
    so each window gets a distinct but dark background.
    """
    h = random.random()
    s = random.uniform(0.4, 0.7)
    l = random.uniform(0.04, 0.12)  # noqa: E741
    r, g, b = colorsys.hls_to_rgb(h, l, s)
    return f"#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}"
