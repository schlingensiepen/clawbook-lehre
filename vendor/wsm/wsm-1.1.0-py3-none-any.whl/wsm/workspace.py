"""Project creation from template with git initialization."""

import logging
import shutil
import subprocess
from pathlib import Path

from wsm.models import Location
from wsm.paths import sanitize_name
from wsm.scanner import git_run

logger = logging.getLogger("wsm")


# Written into a fresh repo so line-ending churn never shows up in diffs.
# The file is created only when no .gitattributes exists yet -- user/template
# customizations are preserved.
#
# "* -text" means: git treats every file as binary -- no auto-detection, no
# normalization, no eol conversion on checkout. Files land in the repo
# byte-for-byte as they are on disk, and `git status`/`git diff` only fire
# when bytes actually change. Trade-off: the repo will contain whatever
# eol style the author committed with, mixing CRLF and LF is possible if
# multiple people contribute from different platforms -- that is acceptable
# here because we don't want git to "help" with conversions.
_DEFAULT_GITATTRIBUTES = "* -text\n"


def _ensure_gitattributes(project_path: Path) -> bool:
    """Write a default .gitattributes if none exists yet.

    Returns True if a new file was created, False if one was already there.
    """
    target = project_path / ".gitattributes"
    if target.exists():
        return False
    try:
        # Write LF-terminated even on Windows so the file's own eol matches
        # what it declares for *.md / *.py etc.
        target.write_bytes(_DEFAULT_GITATTRIBUTES.encode("utf-8"))
        logger.info(".gitattributes erzeugt: %s", target)
        return True
    except OSError as exc:
        logger.warning(".gitattributes konnte nicht geschrieben werden: %s", exc)
        return False


def _resolve_template_path(location: Location) -> Path | None:
    """Resolve the template directory for a location.

    Order: explicit `template:` config > `_Template` fallback > none.
    Explicit but missing -> None with a warning logged. Missing fallback
    is silent.

    Returns the absolute Path if a template exists, else None.
    """
    if location.template:
        template_path = location.template_path
        if template_path and template_path.exists():
            return template_path
        if template_path:
            logger.warning("Template-Ordner nicht gefunden: %s", template_path)
        return None
    fallback = location.path / "_Template"
    if fallback.exists():
        return fallback
    return None


def _is_dotpath(rel_parts: tuple[str, ...]) -> bool:
    """Return True if any segment of a relative path starts with '.'."""
    return any(part.startswith(".") for part in rel_parts)


def compute_template_gaps(
    project_path: Path, template_path: Path,
) -> list[Path]:
    """Return relative paths from `template_path` that are missing in `project_path`.

    Walks the template top-down. Skips dot-directories (and dot-files) at any
    level — analog to the ignore pattern used in create_project. Compares only
    by existence of the relative target path, not content.

    Returns a list of relative Path objects, ordered so directories appear
    before files contained in them.
    """
    if not template_path.exists():
        return []

    gaps: list[Path] = []
    for entry in sorted(template_path.rglob("*")):
        rel = entry.relative_to(template_path)
        if _is_dotpath(rel.parts):
            continue
        target = project_path / rel
        if not target.exists():
            gaps.append(rel)
    return gaps


def init_template(
    project_path: Path, location: Location,
) -> tuple[list[str], list[str]] | None:
    """Copy missing template files into project_path without overwriting.

    Returns (copied, skipped) as lists of relative path strings, or None if
    no template is configured/available.
    """
    template_path = _resolve_template_path(location)
    if template_path is None:
        return None

    copied: list[str] = []
    skipped: list[str] = []

    for entry in sorted(template_path.rglob("*")):
        rel = entry.relative_to(template_path)
        if _is_dotpath(rel.parts):
            continue
        rel_str = str(rel).replace("\\", "/")
        target = project_path / rel

        if target.exists():
            if entry.is_file():
                skipped.append(rel_str)
            continue

        try:
            if entry.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(entry), str(target))
                copied.append(rel_str)
        except OSError as exc:
            logger.warning("Kopieren fehlgeschlagen fuer %s: %s", rel_str, exc)

    return copied, skipped


def init_full(
    project_path: Path, location: Location,
) -> tuple[bool, list[str], list[str]]:
    """Run template init followed by git init.

    Template gaps are filled first so the initial commit picks them up.

    Returns (git_ok, copied, skipped). Empty lists if no template was applied.
    """
    template_result = init_template(project_path, location)
    copied, skipped = template_result if template_result is not None else ([], [])
    git_ok = init_git(project_path, location)
    return git_ok, copied, skipped


def _classify_status(status_output: str) -> tuple[int, int]:
    """Count staged vs. untracked entries in a 'git status --porcelain' output.

    Each line begins with a 2-char status code:
        '?? path' = untracked
        anything else (e.g. 'A ', 'M ', 'D ', 'R ', ...) = staged change

    Returns (staged, untracked) -- counts, not paths.
    """
    if not status_output or not status_output.strip():
        return (0, 0)
    lines = [l for l in status_output.splitlines() if l.strip()]
    untracked = sum(1 for l in lines if l.startswith("??"))
    staged = len(lines) - untracked
    return (staged, untracked)


def _run_local_init(project_path: Path, location: Location) -> bool:
    """Run the local-only init steps shared by create_project and init_git.

    Sequence: git init -b main → user.name/email config → .gitattributes
    → git add . → diagnose stage state → git commit (only if files were
    actually staged).

    Returns True if there is a commit on HEAD afterwards (or the
    directory was legitimately empty); False if files were present but
    'git add .' silently failed to stage them. The caller can use this
    -- combined with has_commits() -- to decide whether a push makes
    sense.

    Timeouts:
      - 'git add .' and 'git commit' on big repos can take minutes
        (index hashing, tree write). Generous timeouts here -- 30 min
        for add, 5 min for commit. If the user wants to abort, Ctrl+C
        works the usual way.
    """
    git_run(["init", "-b", "main"], cwd=project_path, timeout=30, verbose=True)

    if location.git.name:
        git_run(["config", "user.name", location.git.name], cwd=project_path)
    if location.git.email:
        git_run(["config", "user.email", location.git.email], cwd=project_path)

    _ensure_gitattributes(project_path)

    # 'git add -v' prints "add '<path>'" per staged file -- gives the user
    # immediate visual feedback during init that something is happening.
    # Without -v the operation is silent, which made an earlier
    # filesystem-timing bug (where 'git add .' staged nothing) very hard
    # to spot.
    git_run(["add", "-v", "."], cwd=project_path, timeout=1800, verbose=True)

    status = git_run(["status", "--porcelain"], cwd=project_path, timeout=60)
    staged, untracked = _classify_status(status or "")
    logger.info("Stage-Resultat: %d staged, %d untracked", staged, untracked)

    if staged == 0 and untracked == 0:
        logger.info("Keine Dateien zum Committen — Verzeichnis ist leer.")
        return True

    if staged == 0 and untracked > 0:
        # 'git add .' had no effect even though files exist. Observed once
        # on a /mnt/c WSL mount -- likely filesystem-timing related. Don't
        # silently produce a half-broken repo: stop, tell the user.
        logger.warning(
            "'git add .' hat 0 Dateien gestaged, obwohl %d untracked "
            "Eintraege vorhanden sind. Initial-Commit uebersprungen. "
            "Bitte manuell pruefen:\n"
            "    cd \"%s\"\n"
            "    git add .\n"
            "    git commit -m 'Initial commit'\n"
            "Anschliessend [G]/[F] in wsm erneut starten.",
            untracked, project_path,
        )
        return False

    if untracked > 0:
        # Some staged, some still untracked -- proceed but warn so the user
        # knows the initial commit is incomplete. Common cause: gitignore
        # rules, or files git refused to add (e.g. broken symlinks).
        logger.warning(
            "%d Dateien werden im Initial-Commit nicht enthalten sein "
            "(noch untracked nach 'git add .'). %d Dateien werden committed.",
            untracked, staged,
        )

    git_run(
        ["commit", "-m", "Initial commit"],
        cwd=project_path, timeout=300, verbose=True,
    )
    return True


def has_commits(project_path: Path) -> bool:
    """True if HEAD points to at least one commit.

    Used as a safety-net before launch_push: an initial-push without any
    commits fails with the cryptic 'src refspec main does not match any'
    message. Better to skip the push and tell the user clearly.
    """
    return git_run(
        ["rev-parse", "--verify", "HEAD"],
        cwd=project_path, timeout=5,
    ) is not None


def setup_remote(project_path: Path, location: Location) -> bool:
    """Create the remote (gh repo create or git remote add). No push.

    Dispatches by location.git.create_remote ('gh' vs 'push').
    Returns True when a remote is wired up and ready for an initial push,
    False if the operation failed (e.g. gh not authenticated, server down).
    """
    project_name = project_path.name
    if location.git.create_remote == "gh":
        return _create_remote_gh(project_name, project_path, location)
    return _create_remote_push(
        project_path, location.git.remote_url(project_name),
    )


def has_remote(project_path: Path, name: str = "origin") -> bool:
    """True if `name` is among the configured remotes for project_path."""
    out = git_run(["remote"], cwd=project_path, timeout=5)
    if not out:
        return False
    return name in [line.strip() for line in out.splitlines() if line.strip()]


def create_project(
    display_name: str,
    location: Location,
    dry_run: bool = False,
) -> Path | None:
    """Create a new project from the location's template.

    Steps:
        1. Sanitize the project name
        2. Copy template directory (skip dot-directories like .git, .claude)
        3. Run local init (_run_local_init): git init / config /
           .gitattributes / add / initial commit
        4. Create remote (setup_remote) -- without push.

    The initial push is the caller's job: check has_remote(path) and call
    launch_push([path]) which spawns 'wsm push <path>' in its own window.

    Args:
        display_name: User-provided project name (will be sanitized).
        location: The location where the project is created.
        dry_run: If True, only log what would be done.

    Returns:
        Path to the new project directory, or None on failure.
    """
    project_name = sanitize_name(display_name)
    if not project_name:
        logger.warning("Projektname ist nach Bereinigung leer: '%s'", display_name)
        return None

    project_path = location.path / project_name
    remote_url = location.git.remote_url(project_name)

    template_path = _resolve_template_path(location)
    template_explicit = bool(location.template)

    logger.info("Neues Projekt: %s", project_name)
    logger.info("  Pfad:     %s", project_path)
    logger.info("  Remote:   %s", remote_url)
    logger.info("  Template: %s", template_path or "(keins)")

    if project_path.exists():
        logger.warning("Projektordner existiert bereits: %s", project_path)
        return None

    # Explicit template that doesn't exist -> abort (matches old behavior)
    if template_explicit and template_path is None:
        return None

    if dry_run:
        logger.info("(Dry-Run) Wuerde Projekt anlegen: %s", project_path)
        return project_path

    if template_path:
        # Copy template, skip all dot-directories (.git, .claude, etc.)
        try:
            shutil.copytree(
                str(template_path),
                str(project_path),
                ignore=shutil.ignore_patterns(".*"),
            )
            logger.info("Template kopiert (ohne Dot-Ordner).")
        except OSError as exc:
            logger.warning("Fehler beim Kopieren des Templates: %s", exc)
            return None
    else:
        project_path.mkdir(parents=True, exist_ok=True)
        logger.info("Kein Template — leeres Projektverzeichnis erstellt.")

    _run_local_init(project_path, location)
    setup_remote(project_path, location)

    logger.info("Projekt '%s' erfolgreich angelegt.", project_name)
    return project_path


def _create_remote_gh(project_name: str, project_path: Path, location: Location) -> bool:
    """Create a private GitHub repo via gh CLI. No push.

    Returns True if the remote was created (and 'gh' wired up origin
    automatically via --source), False on failure.
    """
    gh_repo = f"{location.git.owner}/{project_name}"
    try:
        result = subprocess.run(
            [
                "gh", "repo", "create", gh_repo,
                "--private",
                "--source", str(project_path),
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode == 0:
            logger.info("GitHub-Repo erstellt: %s", gh_repo)
            return True
        stderr = result.stderr.strip() if result.stderr else ""
        stdout = result.stdout.strip() if result.stdout else ""
        detail = stderr or stdout or "(keine Details)"
        logger.warning(
            "gh repo create fehlgeschlagen (exit code %d): %s",
            result.returncode, detail,
        )
        return False
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        logger.warning("gh CLI nicht verfuegbar oder Timeout: %s", exc)
        return False


def _create_remote_push(project_path: Path, remote_url: str) -> bool:
    """Add 'origin' remote (push-to-create on Gitea/Forgejo). No push.

    Returns True if the remote was added. The actual repo on the server
    is created lazily on first push (push-to-create), so 'success' here
    only means the local 'git remote add' worked.
    """
    result = git_run(
        ["remote", "add", "origin", remote_url],
        cwd=project_path, verbose=True,
    )
    return result is not None


def init_git(project_path: Path, location: Location) -> bool:
    """Initialize an existing directory as a git repo and wire up the remote.

    Calls _run_local_init then setup_remote. The initial push is left to
    the caller (launch_push -> separate window).

    Returns True if local-init succeeded.
    """
    project_name = project_path.name
    remote_url = location.git.remote_url(project_name)

    logger.info("Git initialisieren: %s", project_path)
    logger.info("  Remote: %s", remote_url)

    _run_local_init(project_path, location)
    setup_remote(project_path, location)

    logger.info("Git initialisiert: %s", project_name)
    return True
