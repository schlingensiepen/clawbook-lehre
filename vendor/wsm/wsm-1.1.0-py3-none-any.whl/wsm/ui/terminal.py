"""TUI components using Rich for colored, formatted terminal output."""

import logging
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.text import Text

from wsm.models import DataSummary, DevState, DEVSTATE_DISPLAY_ORDER, ProjectInfo

logger = logging.getLogger("wsm")

console = Console()

# Color scheme for devstate categories
_DEVSTATE_COLORS = {
    DevState.UNPROCESSED: "bright_red",
    DevState.ACTIVE: "bright_green",
    DevState.MIGRATING: "bright_yellow",
    DevState.DEPRECATED: "dim",
    DevState.NO_GIT: "bright_black",
}

_DEVSTATE_LABELS = {
    DevState.UNPROCESSED: "unbearbeitet",
    DevState.ACTIVE: "active",
    DevState.MIGRATING: "migrating",
    DevState.DEPRECATED: "deprecated",
    DevState.NO_GIT: "kein Git-Repo",
}


def print_header(title: str = "Workspace Manager") -> None:
    """Print the application header."""
    console.print(Panel(f"[bold cyan]{title}[/]", border_style="cyan"))


def print_info(key: str, value: str) -> None:
    """Print a key-value info line."""
    console.print(f"  [blue]{key}:[/] {value}")


def print_success(message: str) -> None:
    """Print a success message."""
    console.print(f"  [green]✓[/] {message}")


def print_warning(message: str) -> None:
    """Print a warning message."""
    console.print(f"  [yellow]![/] {message}")
    logger.warning(message)


def print_error(message: str) -> None:
    """Print an error message."""
    console.print(f"  [red]✗[/] {message}")
    logger.error(message)


def print_project_list(
    grouped: dict[DevState, list[ProjectInfo]],
    location_label: str = "",
    annotations: dict | None = None,
) -> list[ProjectInfo]:
    """Display categorized project list and return flat numbered list.

    Args:
        grouped: Projects grouped by DevState.
        location_label: Optional header.
        annotations: Optional dict mapping project.path -> annotation string
            (for [D] Details). When provided, each project gets an inline
            "(annotation)" suffix. Without it, the list is rendered fast
            and clean.

    Returns:
        Flat list of all projects in display order (for index-based selection).
    """
    if location_label:
        console.print(f"\n  [bold]Location:[/] {location_label}")

    flat_list: list[ProjectInfo] = []
    index = 1
    annotations = annotations or {}

    for state in DEVSTATE_DISPLAY_ORDER:
        if state not in grouped:
            continue

        projects = grouped[state]
        color = _DEVSTATE_COLORS[state]
        label = _DEVSTATE_LABELS[state]

        console.print(f"\n  [bold {color}]── {label} ──[/]")

        for project in projects:
            flat_list.append(project)
            name_display = f"[{color}]{project.name}[/]"
            note = annotations.get(project.path)
            suffix = f"  [dim]({note})[/]" if note else ""
            console.print(f"    {index:>3}. {name_display}{suffix}")
            index += 1

    console.print()
    return flat_list


def select_project(flat_list: list[ProjectInfo]) -> ProjectInfo | str | None:
    """Prompt user to select a project by number.

    Returns:
        ProjectInfo if a project was selected,
        "n" Neu, "m" Multi-Start, "f" Multi-Init, "z" Multi-Zip,
        "r" Remote-Check, "d" Details, None on quit.
    """
    total = len(flat_list)
    choice = Prompt.ask(
        f"  Auswahl (1-{total} / "
        f"[bold]\\[N][/] Neu  "
        f"[bold]\\[M][/] Multi-Start  "
        f"[bold]\\[F][/] Multi-Init  "
        f"[bold]\\[Z][/] Multi-Zip  "
        f"[bold]\\[R][/] Multi-Push  "
        f"[bold]\\[D][/] Details  "
        f"[bold]\\[Q][/] Quit)",
    )
    choice = choice.strip().lower()

    if choice == "q":
        return None
    if choice in ("n", "m", "f", "z", "r", "d"):
        return choice

    try:
        idx = int(choice) - 1
        if 0 <= idx < total:
            return flat_list[idx]
    except ValueError:
        pass

    print_error(f"Ungueltige Auswahl: {choice}")
    return select_project(flat_list)


def parse_range_selection(selection: str, max_val: int) -> list[int]:
    """Parse a range selection like '1,3,5-8' into a sorted list of indices (0-based).

    Args:
        selection: Comma-separated numbers and ranges (1-based).
        max_val: Maximum valid value (1-based, inclusive).

    Returns:
        Sorted list of unique 0-based indices.
    """
    indices: set[int] = set()
    for part in selection.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            bounds = part.split("-", 1)
            try:
                start = int(bounds[0].strip())
                end = int(bounds[1].strip())
                for i in range(start, end + 1):
                    if 1 <= i <= max_val:
                        indices.add(i - 1)
            except ValueError:
                continue
        else:
            try:
                val = int(part)
                if 1 <= val <= max_val:
                    indices.add(val - 1)
            except ValueError:
                continue
    return sorted(indices)


def select_multi_projects(flat_list: list[ProjectInfo]) -> list[ProjectInfo]:
    """Prompt user to select multiple projects by number ranges.

    Accepted inputs:
        '1,3,5-8'   — explicit range
        'a' / 'A'   — all projects
        'q' / 'Q'   — abort, returns empty list

    Returns:
        List of selected ProjectInfo objects.
    """
    total = len(flat_list)
    selection = Prompt.ask(
        f"  Projekte (z.B. 1,3,5-8 / "
        f"[bold]\\[A][/] Alle / "
        f"[bold]\\[Q][/] Abbrechen)",
    )
    choice = selection.strip().lower()
    if choice == "q":
        return []
    if choice == "a":
        selected = list(flat_list)
        console.print(f"  Alle {len(selected)} Projekte ausgewaehlt.")
        return selected

    indices = parse_range_selection(selection, total)
    if not indices:
        print_error("Keine gueltige Auswahl.")
        return []

    selected = [flat_list[i] for i in indices]
    console.print(f"  {len(selected)} Projekte ausgewaehlt:")
    for p in selected:
        console.print(f"    - {p.name}")
    return selected


def show_project_detail(
    project: ProjectInfo,
    data_summary: DataSummary | None = None,
) -> None:
    """Display project details with optional data summary."""
    state_color = _DEVSTATE_COLORS.get(project.devstate, "white")
    state_label = _DEVSTATE_LABELS.get(project.devstate, "?")

    console.print(f"\n  [bold cyan]── {project.name} ──[/]")
    if project.is_git_repo:
        console.print(f"  [blue]Branch:[/]   {project.git_branch}")
        console.print(f"  [blue]Commit:[/]   {project.git_last_commit}")
    console.print(f"  [blue]Devstate:[/] [{state_color}]{state_label}[/]")

    if data_summary is not None:
        raw_info = f"{data_summary.raw_count} Dateien" if data_summary.raw_count else "leer"
        console.print(f"  [blue]raw/:[/]     {raw_info}")

        if data_summary.linked_count:
            names = ", ".join(data_summary.linked_names)
            console.print(f"  [blue]Quellen:[/]  {data_summary.linked_count} verlinkt ({names})")
        else:
            console.print(f"  [blue]Quellen:[/]  keine")

        if data_summary.input_count or data_summary.pending_count:
            pending_str = (
                f" [bright_yellow]({data_summary.pending_count} raw ausstehend)[/]"
                if data_summary.pending_count
                else ""
            )
            console.print(f"  [blue]input/:[/]   {data_summary.input_count} Dateien{pending_str}")

    console.print()


_STATUS_STYLES = {
    "aktuell": "[green]aktuell[/]",
    "veraltet": "[bright_yellow]veraltet[/]",
    "neu": "[bright_red]neu[/]",
}


def show_project_data(
    project_name: str,
    detail: list[tuple[str, str, list[tuple[str, str]]]],
) -> None:
    """Display detailed file listing with sync status.

    Args:
        project_name: Name of the project.
        detail: List of (source_name, source_path, [(filename, status), ...]).
    """
    console.print(f"\n  [bold cyan]── Datenlage: {project_name} ──[/]")

    if not detail:
        console.print("  [dim]Keine Daten vorhanden.[/]")
        console.print()
        return

    for source_name, source_path, files in detail:
        console.print(f"\n  [bold]{source_name}/[/]  [dim]{source_path}[/]")
        if not files:
            console.print("    [dim](leer)[/]")
        else:
            for filename, status in files:
                styled = _STATUS_STYLES.get(status, status)
                console.print(f"    {filename}  {styled}")
    console.print()


def select_action(
    is_git_repo: bool = True,
    template_has_gaps: bool = False,
) -> str | None:
    """Prompt user to select an action for a project.

    Visibility rules:
        [G] Git Init      -- only when not a git repo
        [F] Full Init     -- only when not a git repo AND template has gaps
        [T] Template Init -- only when template has gaps
        [R] Remotes       -- only when git repo

    Shell shortcut is platform-dependent: [B] Bash on Linux, [K] Cmd on Windows.
    """
    is_windows = sys.platform == "win32"
    if is_windows:
        shell_part = "[dim]\\[K][/] Cmd  "
        shell_keys = {"k"}
    else:
        shell_part = "[dim]\\[B][/] Bash  "
        shell_keys = {"b"}

    init_parts = ""
    init_keys: set[str] = set()
    if not is_git_repo and template_has_gaps:
        init_parts += "[bright_yellow]\\[F][/] Full Init  "
        init_keys.add("f")
    if not is_git_repo:
        init_parts += "[bright_yellow]\\[G][/] Git Init  "
        init_keys.add("g")
    if template_has_gaps:
        init_parts += "[bright_yellow]\\[T][/] Template Init  "
        init_keys.add("t")
    remote_part = "[dim]\\[R][/] Remotes  " if is_git_repo else ""
    if is_git_repo:
        init_keys.add("r")

    console.print(
        "  [green]\\[S][/] Starten  "
        "[cyan]\\[C][/] Kopieren  "
        "[yellow]\\[I][/] Importieren  "
        "[blue]\\[L][/] Linken  "
        "[bright_yellow]\\[U][/] Sync  "
        "[white]\\[D][/] Daten  "
        "[magenta]\\[E][/] Explorer  "
        + shell_part +
        "[dim]\\[P][/] PowerShell  "
        + init_parts
        + "[bright_blue]\\[Z][/] Zip  "
        + remote_part +
        "[red]\\[Q][/] Zurueck"
    )
    valid = {"s", "c", "i", "l", "u", "d", "e", "p", "q", "z"} | shell_keys | init_keys
    choice = Prompt.ask("  Aktion").strip().lower()
    if choice in valid:
        return choice
    print_error(f"Ungueltige Aktion: {choice}")
    return select_action(is_git_repo, template_has_gaps)


def select_prompt(prompts: dict[str, str]) -> tuple[str, str | None]:
    """Display prompt selection menu with full prompt text.

    Returns:
        Tuple of (prompt_name, prompt_text).
        Special names: "resume" (--resume), "open" (no prompt), "quit" (cancel).
    """
    console.print("\n  [bold]Prompt waehlen:[/]")
    console.print(f"    [green]1.[/] resume")
    console.print(f"       [dim]Letzte Session fortsetzen (claude --resume)[/]")
    console.print(f"    [green]2.[/] ohne Prompt")
    console.print(f"       [dim]Claude Code interaktiv starten[/]")

    prompt_list = list(prompts.items())
    for i, (name, text) in enumerate(prompt_list, start=3):
        console.print(f"    [green]{i}.[/] {name}")
        for line in text.strip().splitlines():
            console.print(f"       [dim]{line.strip()}[/]")

    total = len(prompt_list) + 2
    console.print(f"\n  [red]\\[Q][/] Zurueck")
    choice = Prompt.ask(f"  Auswahl (1-{total} / q=Zurueck)", default="1")
    choice = choice.strip().lower()

    if choice == "q":
        return ("quit", None)

    try:
        idx = int(choice)
    except ValueError:
        print_error(f"Ungueltige Auswahl: {choice}")
        return select_prompt(prompts)

    if idx == 1:
        return ("resume", None)
    if idx == 2:
        return ("open", None)

    prompt_idx = idx - 3
    if 0 <= prompt_idx < len(prompt_list):
        name, text = prompt_list[prompt_idx]
        return (name, text)

    print_error(f"Ungueltige Auswahl: {choice}")
    return select_prompt(prompts)


def select_location(location_labels: list[str], show_sync: bool = False) -> int | str | None:
    """Prompt user to select a location.

    Args:
        location_labels: List of location path strings.
        show_sync: If True, show [U] Sync option.

    Returns:
        Index of selected location, "u" for sync all, or None to quit.
    """
    console.print("\n  [bold]Location waehlen:[/]")
    for i, label in enumerate(location_labels, start=1):
        console.print(f"    {i}. {label}")

    if show_sync:
        console.print()
        console.print(
            "  [bright_yellow]\\[U][/] Sync alle  "
            "[red]\\[Q][/] Beenden"
        )

    default = "1" if len(location_labels) == 1 else ""
    n = len(location_labels)
    sync_hint = " / u=Sync alle" if show_sync else ""
    choice = Prompt.ask(
        f"  Auswahl (1-{n}{sync_hint} / q=Quit)",
        default=default,
    )
    choice = choice.strip().lower()

    if choice == "q":
        return None
    if show_sync and choice == "u":
        return "u"

    try:
        idx = int(choice) - 1
        if 0 <= idx < len(location_labels):
            return idx
    except ValueError:
        pass

    print_error(f"Ungueltige Auswahl: {choice}")
    return select_location(location_labels, show_sync=show_sync)


def confirm(message: str) -> bool:
    """Ask for confirmation."""
    return Confirm.ask(f"  {message}")


def ask_text(prompt: str, default: str = "") -> str:
    """Ask for text input."""
    return Prompt.ask(f"  {prompt}", default=default).strip()


def print_sync_summary(
    project_name: str,
    converted: int,
    skipped: int,
    errors: int,
) -> None:
    """Print a sync summary line for a project."""
    parts = []
    if converted > 0:
        parts.append(f"[green]{converted} konvertiert[/]")
    if skipped > 0:
        parts.append(f"[dim]{skipped} uebersprungen[/]")
    if errors > 0:
        parts.append(f"[red]{errors} Fehler[/]")
    if not parts:
        parts.append("[dim]nichts zu tun[/]")

    console.print(f"  {project_name}: {', '.join(parts)}")


def print_clipboard_preview(
    existing: list[Path],
    new: list[Path],
) -> None:
    """Show what's already present and what's new from clipboard."""
    if existing:
        console.print(f"\n  [dim]Bereits vorhanden ({len(existing)}):[/]")
        for p in existing[:10]:
            console.print(f"    [dim]✓ {p.name}[/]")
        if len(existing) > 10:
            console.print(f"    [dim]... und {len(existing) - 10} weitere[/]")

    if new:
        console.print(f"\n  [green]Neu ({len(new)}):[/]")
        for p in new[:10]:
            console.print(f"    [green]+ {p.name}[/]")
        if len(new) > 10:
            console.print(f"    [green]... und {len(new) - 10} weitere[/]")

    console.print()
