"""Windows platform backend: cmd.exe windows, WSL, PowerShell clipboard."""

import ctypes
import logging
import subprocess
import sys
from pathlib import Path

from wsm.paths import windows_to_wsl
from wsm.platform_base import PlatformBackend
from wsm.utils import random_dark_color

logger = logging.getLogger("wsm")

# PowerShell command to get file drop list from clipboard
_PS_CLIPBOARD_FILES = (
    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
    "$files = Get-Clipboard -Format FileDropList; "
    "if ($files) { $files | ForEach-Object { $_.FullName } }"
)


def _restore_console_mode() -> None:
    """Re-enable ANSI escape processing and basic output handling on Windows.

    Launching subprocesses via 'start cmd.exe' (shell=True) can reset the
    console output mode, breaking both ANSI colors and basic control chars
    like newlines.  This restores all required flags on stdout:
      - ENABLE_PROCESSED_OUTPUT  (0x0001): \\n, \\r, \\t etc.
      - ENABLE_WRAP_AT_EOL_OUTPUT (0x0002): line wrapping
      - ENABLE_VIRTUAL_TERMINAL_PROCESSING (0x0004): ANSI escape sequences
    """
    if sys.platform != "win32":
        return
    try:
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            mode.value |= 0x0007  # all three output flags
            kernel32.SetConsoleMode(handle, mode)
    except Exception:  # noqa: BLE001
        pass


class WindowsBackend(PlatformBackend):
    """Windows implementation using cmd.exe, WSL, and PowerShell."""

    def launch_claude(
        self,
        project_path: Path,
        distro: str,
        prompt: str | None = None,
        resume: bool = False,
    ) -> bool:
        wsl_path = windows_to_wsl(project_path)
        project_name = project_path.name

        if resume:
            claude_cmd = "claude --resume"
        elif prompt:
            clean = " ".join(prompt.split())
            escaped = clean.replace("'", "'\\''")
            claude_cmd = f"claude '{escaped}'"
        else:
            claude_cmd = "claude"

        bg_color = random_dark_color()
        set_bg = f"echo -e '\\e]11;{bg_color}\\a'"
        bash_cmd = f"{set_bg}; cd '{wsl_path}' && {claude_cmd}; echo; read -p 'Enter zum Schliessen...'"
        title = f"Claude: {project_name}"

        cmd = f'start "{title}" wsl.exe -d {distro} -- bash -ic "{bash_cmd}"'
        print(f"  > {cmd}")

        try:
            subprocess.run(cmd, shell=True, check=False)
            _restore_console_mode()
            logger.info("Claude-Fenster gestartet: %s", project_name)
            return True
        except OSError as exc:
            logger.warning("Fenster konnte nicht geoeffnet werden: %s", exc)
            return False

    def launch_sync(
        self,
        project_name: str | None = None,
        config_path: Path | None = None,
    ) -> bool:
        wsm_parts = ["wsm"]
        if config_path:
            wsm_parts.extend(["--config", str(config_path)])
        wsm_parts.append("update")
        if project_name:
            wsm_parts.append(project_name)
        wsm_cmd = " ".join(wsm_parts)

        inner_cmd = f"call mamba activate WorkSpaceManager && {wsm_cmd} & pause"
        title = f"Sync: {project_name}" if project_name else "Sync: alle Projekte"

        cmd = f'start "{title}" cmd.exe /k "{inner_cmd}"'
        print(f"  > {cmd}")

        try:
            subprocess.run(cmd, shell=True, check=False)
            _restore_console_mode()
            logger.info("Sync-Fenster gestartet: %s", project_name)
            return True
        except OSError as exc:
            logger.warning("Sync-Fenster konnte nicht geoeffnet werden: %s", exc)
            return False

    def launch_export(
        self,
        project_paths: list[Path],
        config_path: Path | None = None,
    ) -> bool:
        return self._launch_subcommand(
            subcommand="export",
            project_paths=project_paths,
            config_path=config_path,
            title_singular="Export",
            title_plural_label="Projekte",
        )

    def launch_push(
        self,
        project_paths: list[Path],
        config_path: Path | None = None,
    ) -> bool:
        return self._launch_subcommand(
            subcommand="push",
            project_paths=project_paths,
            config_path=config_path,
            title_singular="Push",
            title_plural_label="Projekte",
        )

    def _launch_subcommand(
        self,
        subcommand: str,
        project_paths: list[Path],
        config_path: Path | None,
        title_singular: str,
        title_plural_label: str,
    ) -> bool:
        """Shared spawner for export/push: opens cmd.exe with 'wsm <sub> <paths...>'.

        All paths are double-quoted so that spaces (and UNC paths) survive
        the cmd.exe parser.
        """
        if not project_paths:
            return False

        wsm_parts = ["wsm"]
        if config_path:
            wsm_parts.extend(["--config", f'"{config_path}"'])
        wsm_parts.append(subcommand)
        for path in project_paths:
            wsm_parts.append(f'"{path}"')
        wsm_cmd = " ".join(wsm_parts)

        inner_cmd = f"call mamba activate WorkSpaceManager && {wsm_cmd} & pause"
        if len(project_paths) == 1:
            title = f"{title_singular}: {project_paths[0].name}"
        else:
            title = f"{title_singular}: {len(project_paths)} {title_plural_label}"

        cmd = f'start "{title}" cmd.exe /k "{inner_cmd}"'
        print(f"  > {cmd}")

        try:
            subprocess.run(cmd, shell=True, check=False)
            _restore_console_mode()
            logger.info("%s-Fenster gestartet: %d Projekt(e)",
                        title_singular, len(project_paths))
            return True
        except OSError as exc:
            logger.warning("%s-Fenster konnte nicht geoeffnet werden: %s",
                           title_singular, exc)
            return False

    def open_explorer(self, project_path: Path) -> bool:
        try:
            subprocess.Popen(["explorer.exe", str(project_path)])
            _restore_console_mode()
            logger.info("Explorer geoeffnet: %s", project_path)
            return True
        except OSError as exc:
            logger.warning("Explorer konnte nicht geoeffnet werden: %s", exc)
            return False

    def open_shell(self, project_path: Path) -> bool:
        title = f"Shell: {project_path.name}"
        cmd = f'start "{title}" cmd.exe /k "cd /d {project_path}"'
        try:
            subprocess.run(cmd, shell=True, check=False)
            _restore_console_mode()
            logger.info("Shell geoeffnet: %s", project_path)
            return True
        except OSError as exc:
            logger.warning("Shell konnte nicht geoeffnet werden: %s", exc)
            return False

    def open_powershell(self, project_path: Path) -> bool:
        title = f"PowerShell: {project_path.name}"
        cmd = (
            f'start "{title}" powershell.exe '
            f'-NoExit -Command "Set-Location -LiteralPath \'{project_path}\'"'
        )
        try:
            subprocess.run(cmd, shell=True, check=False)
            _restore_console_mode()
            logger.info("PowerShell geoeffnet: %s", project_path)
            return True
        except OSError as exc:
            logger.warning("PowerShell konnte nicht geoeffnet werden: %s", exc)
            return False

    def open_editor(self, file_path: Path) -> bool:
        try:
            subprocess.Popen(["notepad.exe", str(file_path)])
            logger.info("Editor geoeffnet: %s", file_path)
            return True
        except OSError as exc:
            logger.warning("Editor konnte nicht geoeffnet werden: %s", exc)
            return False

    def read_clipboard_paths(self) -> list[Path]:
        try:
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-Command", _PS_CLIPBOARD_FILES],
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=10,
            )
            if result.returncode != 0:
                logger.debug("PowerShell clipboard read failed: %s", result.stderr.strip())
                return []

            lines = result.stdout.strip().splitlines()
            paths = []
            for line in lines:
                line = line.strip()
                if line:
                    paths.append(Path(line))
            return paths

        except FileNotFoundError:
            logger.warning("powershell.exe nicht gefunden. Laeuft das Tool unter Windows?")
            return []
        except subprocess.TimeoutExpired:
            logger.warning("Timeout beim Lesen der Zwischenablage.")
            return []

    def restore_console(self) -> None:
        _restore_console_mode()
