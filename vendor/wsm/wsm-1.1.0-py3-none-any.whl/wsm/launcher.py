"""Launch Claude Code and open file manager -- delegates to platform backend."""

import logging
from pathlib import Path

from wsm.platform import get_platform

logger = logging.getLogger("wsm")


def launch_claude(
    project_path: Path,
    distro: str,
    prompt: str | None = None,
    resume: bool = False,
) -> bool:
    """Launch Claude Code in a new window/session.

    Args:
        project_path: Path to the project directory.
        distro: WSL distribution name (ignored on Linux).
        prompt: Prompt string to pass to claude. Ignored if resume is True.
        resume: If True, resume the last session (claude --resume).

    Returns:
        True if the window/session was opened successfully.
    """
    return get_platform().launch_claude(project_path, distro, prompt, resume)


def launch_sync(
    project_name: str | None = None,
    config_path: Path | None = None,
) -> bool:
    """Launch a background sync (wsm update) in a separate window/session.

    Args:
        project_name: Name of the project to sync, or None for all projects.
        config_path: Optional config path to pass to wsm.

    Returns:
        True if the window/session was opened successfully.
    """
    return get_platform().launch_sync(project_name, config_path)


def launch_export(
    project_paths: list[Path],
    config_path: Path | None = None,
) -> bool:
    """Launch `wsm export <paths...>` in a separate window/session.

    Sequentially exports each project as a 7z archive. The window stays
    open after completion (pause / read).

    Args:
        project_paths: One or more project directories to export.
        config_path: Optional config path to pass to wsm.

    Returns:
        True if the window/session was opened successfully.
    """
    return get_platform().launch_export(project_paths, config_path)


def launch_push(
    project_paths: list[Path],
    config_path: Path | None = None,
) -> bool:
    """Launch `wsm push <paths...>` in a separate window/session.

    Sequential 'git push -u origin main' per path. No timeout in the
    spawned subprocess, so big repos won't be reported as failed.

    Args:
        project_paths: One or more project directories whose remote is
            already configured (origin) but not yet pushed.
        config_path: Optional config path to pass to wsm.

    Returns:
        True if the window/session was opened successfully.
    """
    return get_platform().launch_push(project_paths, config_path)


def open_explorer(project_path: Path) -> bool:
    """Open the file manager at the given path."""
    return get_platform().open_explorer(project_path)


def open_shell(project_path: Path) -> bool:
    """Open a shell/terminal at the given path."""
    return get_platform().open_shell(project_path)


def open_powershell(project_path: Path) -> bool:
    """Open PowerShell at the given path."""
    return get_platform().open_powershell(project_path)
