"""Data models for the Workspace Manager."""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class DevState(Enum):
    """Project development states based on devstate_*.md files."""

    UNPROCESSED = "unbearbeitet"
    ACTIVE = "active"
    MIGRATING = "migrating"
    DEPRECATED = "deprecated"
    NO_GIT = "kein Git-Repo"


# Ordered display sequence for categories (top to bottom)
DEVSTATE_DISPLAY_ORDER = [
    DevState.UNPROCESSED,
    DevState.ACTIVE,
    DevState.MIGRATING,
    DevState.DEPRECATED,
    DevState.NO_GIT,
]

# Map devstate filenames to enum values
DEVSTATE_FILE_MAP = {
    "devstate_active.md": DevState.ACTIVE,
    "devstate_deprecated.md": DevState.DEPRECATED,
    "devstate_migrating.md": DevState.MIGRATING,
}


@dataclass
class GitConfig:
    """Git server configuration for a location."""

    url: str
    user: str = ""
    org: str = ""
    name: str = ""
    email: str = ""
    create_remote: str = "push"

    @property
    def owner(self) -> str:
        """Return the repo owner (org takes precedence over user)."""
        return self.org or self.user

    def remote_url(self, project_name: str) -> str:
        """Build the full git remote URL for a project."""
        return f"{self.url}/{self.owner}/{project_name}.git"


@dataclass
class Location:
    """A project directory location with its configuration."""

    path: Path
    git: GitConfig
    template: str = ""
    prompts: dict[str, str] = field(default_factory=dict)
    name: str = ""
    # Set by config.py during based_on inheritance when the child did NOT
    # specify its own 'template'. In that case the parent's absolute
    # template path is recorded here, so the child can reuse the parent's
    # template directory instead of expecting a copy under its own path.
    _template_path_override: Path | None = None

    @property
    def template_path(self) -> Path | None:
        """Full path to the template directory, or None if not configured.

        Resolution order:
          1. _template_path_override (set during based_on inheritance when
             the child has no own 'template' key) -> absolute path from
             the parent.
          2. self.path / self.template -> child has explicit template name,
             resolved relative to its own path.
          3. None -> no template.
        """
        if self._template_path_override is not None:
            return self._template_path_override
        if self.template:
            return self.path / self.template
        return None


@dataclass
class WslConfig:
    """WSL configuration."""

    distro: str = "Ubuntu"


@dataclass
class Config:
    """Root configuration loaded from .workspacemanager.yml."""

    locations: list[Location]
    wsl: WslConfig = field(default_factory=WslConfig)
    docling_servers: list[str] = field(default_factory=list)
    docling_workers_per_server: int = 2
    docling_retry_timeout: int = 180
    ollama_servers: list[str] = field(default_factory=list)
    ollama_vision_model: str = "llava"
    log_file: Path | None = None
    export_path: Path | None = None
    sevenzip_path: Path | None = None


@dataclass
class Source:
    """An external document source reference from doc-sources.yml."""

    name: str
    path: Path


@dataclass
class DocSources:
    """Project document sources loaded from doc-sources.yml."""

    sources: list[Source] = field(default_factory=list)


@dataclass
class ProjectInfo:
    """Information about a scanned project."""

    name: str
    path: Path
    location: Location
    is_git_repo: bool = False
    devstate: DevState = DevState.NO_GIT
    git_branch: str = ""
    git_last_commit: str = ""


@dataclass
class DataSummary:
    """Summary counts for project data (raw, linked, input, pending)."""

    raw_count: int = 0
    linked_count: int = 0
    linked_names: list[str] = field(default_factory=list)
    input_count: int = 0
    pending_count: int = 0
