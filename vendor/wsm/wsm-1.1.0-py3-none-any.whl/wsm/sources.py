"""Document source management: doc-sources.yml handling and sync logic."""

import asyncio
import logging
import shutil
from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import yaml

from wsm.converter import (
    ConversionJob, DoclingPool, OllamaPool, extract_archive,
    is_archive, is_docling_supported, is_image, is_passthrough, is_skippable,
)
from wsm.models import DataSummary, DocSources, Source

logger = logging.getLogger("wsm")

DOC_SOURCES_FILENAME = "doc-sources.yml"
RAW_DIRNAME = "raw"
INPUT_DIRNAME = "input"
SOURCE_FOOTER_TEMPLATE = (
    "\n\n---\n\nQuell-Datei: {source_path}\n\nQuell-Datum: {source_date}\n"
)


def load_doc_sources(project_path: Path) -> DocSources:
    """Load doc-sources.yml from a project directory."""
    yml_path = project_path / DOC_SOURCES_FILENAME
    if not yml_path.exists():
        return DocSources()

    try:
        raw = yaml.safe_load(yml_path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError) as exc:
        logger.warning("Fehler beim Lesen von %s: %s", yml_path, exc)
        return DocSources()

    if not isinstance(raw, dict):
        return DocSources()

    raw_sources = raw.get("sources", [])
    if not isinstance(raw_sources, list):
        return DocSources()

    sources = []
    for entry in raw_sources:
        if isinstance(entry, dict) and "name" in entry and "path" in entry:
            sources.append(Source(name=entry["name"], path=Path(entry["path"])))
    return DocSources(sources=sources)


def save_doc_sources(project_path: Path, doc_sources: DocSources) -> None:
    """Save doc-sources.yml to a project directory."""
    yml_path = project_path / DOC_SOURCES_FILENAME
    data = {
        "sources": [
            {"name": s.name, "path": str(s.path)}
            for s in doc_sources.sources
        ]
    }
    yml_path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    logger.info("doc-sources.yml geschrieben: %s", yml_path)


def _source_footer(source_path: Path) -> str:
    """Generate the source provenance footer for an md file."""
    try:
        mtime = source_path.stat().st_mtime
        date_str = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
    except OSError:
        date_str = "unbekannt"

    return SOURCE_FOOTER_TEMPLATE.format(
        source_path=source_path,
        source_date=date_str,
    )


def _needs_conversion(source_path: Path, target_path: Path) -> bool:
    """Check if source is newer than target (or target doesn't exist)."""
    if not target_path.exists():
        return True
    try:
        return source_path.stat().st_mtime > target_path.stat().st_mtime
    except OSError:
        return True


def _collect_source_files(
    source_path: Path,
    on_file: Callable[[int], None] | None = None,
) -> list[tuple[Path, Path]]:
    """Collect all files from a source, returning (absolute_path, relative_path) pairs.

    If source_path is a file, returns just that file.
    If source_path is a directory, returns all files recursively.
    """
    try:
        if source_path.is_file():
            return [(source_path, Path(source_path.name))]

        if not source_path.is_dir():
            logger.warning("Quelle nicht gefunden: %s", source_path)
            return []
    except OSError as exc:
        logger.warning("Quelle nicht erreichbar: %s (%s)", source_path, exc)
        return []

    files = []
    for file_path in sorted(source_path.rglob("*")):
        if file_path.is_file():
            rel = file_path.relative_to(source_path)
            files.append((file_path, rel))
            if on_file:
                on_file(len(files))
    return files


def _archive_target_dir(source_path: Path) -> Path:
    """Return the extraction directory for an archive (sibling dir, same name without ext)."""
    name = source_path.name
    # Strip compound extensions (.tar.gz, .tar.bz2, .tar.xz)
    for ext in (".tar.gz", ".tar.bz2", ".tar.xz"):
        if name.lower().endswith(ext):
            return source_path.parent / name[: -len(ext)]
    return source_path.parent / source_path.stem


@dataclass
class ScanStats:
    """Detailed statistics from the file collection phase."""

    converted: int = 0
    errors: int = 0
    skip_reasons: Counter = field(default_factory=Counter)

    @property
    def skipped(self) -> int:
        return sum(self.skip_reasons.values())


def _collect_jobs(
    source_files: list[tuple[Path, Path]],
    target_dir: Path,
    on_file: Callable[[int], None] | None = None,
    extract_base: Path | None = None,
) -> tuple[list[ConversionJob], list[ConversionJob], ScanStats]:
    """Categorize source files: handle passthrough and archives, build job lists.

    Archives are extracted to extract_base (preserving relative paths) and their
    contents added to the processing queue.

    Args:
        on_file: Optional callback(files_scanned_so_far) called per file.
        extract_base: Directory for archive extraction. If None, archives are
            extracted next to the source file (only safe for local raw/ dirs).

    Returns:
        (docling_jobs, image_jobs, stats).
    """
    docling_jobs: list[ConversionJob] = []
    image_jobs: list[ConversionJob] = []
    stats = ScanStats()
    scanned = 0

    # Use a mutable list so archives can append extracted files
    pending = list(source_files)
    idx = 0

    while idx < len(pending):
        source_path, rel_path = pending[idx]
        idx += 1
        scanned += 1
        if on_file:
            on_file(scanned)

        if is_skippable(source_path):
            stats.skip_reasons[source_path.name] += 1
            logger.debug("Uebersprungen (Junk): %s", source_path.name)
            continue

        if is_archive(source_path):
            # Extract to extract_base with relative path, or next to source
            archive_name = _archive_target_dir(source_path).name
            if extract_base is not None:
                extract_dir = extract_base / rel_path.parent / archive_name
            else:
                extract_dir = _archive_target_dir(source_path)
            extracted = extract_archive(source_path, extract_dir)
            archive_rel = rel_path.parent / archive_name
            for file_path in extracted:
                inner_rel = archive_rel / file_path.relative_to(extract_dir)
                pending.append((file_path, inner_rel))
            continue

        if is_passthrough(source_path):
            pt_target = target_dir / rel_path  # keep original extension
            if not _needs_conversion(source_path, pt_target):
                ext = source_path.suffix.lower() or "(ohne)"
                stats.skip_reasons[f"{ext} aktuell"] += 1
                continue
            pt_target.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(source_path, pt_target)
                stats.converted += 1
                logger.debug("Kopiert: %s → %s", source_path.name, pt_target)
            except OSError as exc:
                logger.warning("Fehler beim Kopieren von %s: %s", source_path, exc)
                stats.errors += 1
        elif is_image(source_path):
            md_target = target_dir / rel_path.with_suffix(".md")
            if not _needs_conversion(source_path, md_target):
                ext = source_path.suffix.lower() or "(ohne)"
                stats.skip_reasons[f"{ext} aktuell"] += 1
                continue
            try:
                file_size = source_path.stat().st_size
            except OSError:
                file_size = 0
            image_jobs.append(ConversionJob(
                source_path=source_path,
                target_path=md_target,
                file_size=file_size,
                footer=_source_footer(source_path),
            ))
        elif is_docling_supported(source_path):
            md_target = target_dir / rel_path.with_suffix(".md")
            if not _needs_conversion(source_path, md_target):
                ext = source_path.suffix.lower() or "(ohne)"
                stats.skip_reasons[f"{ext} aktuell"] += 1
                continue
            try:
                file_size = source_path.stat().st_size
            except OSError:
                file_size = 0
            docling_jobs.append(ConversionJob(
                source_path=source_path,
                target_path=md_target,
                file_size=file_size,
                footer=_source_footer(source_path),
            ))
        else:
            # Not skippable, not archive, not passthrough, not image, not Docling-supported
            ext = source_path.suffix.lower() or "(ohne)"
            stats.skip_reasons[f"{ext} nicht unterstuetzt"] += 1
            logger.debug("Nicht unterstuetzt: %s", source_path.name)

    return docling_jobs, image_jobs, stats


async def sync_project(
    project_path: Path,
    pool: DoclingPool | None,
    on_progress: Callable[[int, int, int, int], None] | None = None,
    on_scan: Callable[[str, int, int], None] | None = None,
    on_file: Callable[[int], None] | None = None,
    ollama_pool: OllamaPool | None = None,
    on_scan_complete: Callable[[int, int, int, "ScanStats"], None] | None = None,
) -> tuple[int, int, int, ScanStats]:
    """Sync all sources (raw + linked) for a project.

    Phase 1: Collect all files, handle passthrough immediately, build job lists.
    Phase 2: Run Docling conversions in parallel via worker queue.
    Phase 3: Run image descriptions via Ollama in parallel.

    Args:
        on_progress: Callback(completed_bytes, total_bytes, completed_files, remaining).
        on_scan: Callback(source_name, files_found, total_jobs_so_far) during collection.
        on_file: Callback(files_scanned_so_far) called per file during collection.
        ollama_pool: Ollama server pool for image description (None if not configured).
        on_scan_complete: Callback(docling_count, image_count, passthrough_count, stats)
            called after Phase 1, before conversion starts.

    Returns:
        Tuple of (converted, skipped, errors, scan_stats).
    """
    total_converted = 0
    total_errors = 0
    all_docling_jobs: list[ConversionJob] = []
    all_image_jobs: list[ConversionJob] = []
    combined_stats = ScanStats()

    input_dir = project_path / INPUT_DIRNAME

    # Phase 1: collect from all sources
    raw_dir = project_path / RAW_DIRNAME
    if raw_dir.is_dir():
        raw_files = _collect_source_files(raw_dir, on_file)
        raw_target = input_dir / RAW_DIRNAME
        # Archives in raw/ are extracted in-place (raw/ is local)
        d_jobs, i_jobs, stats = _collect_jobs(raw_files, raw_target, on_file)
        all_docling_jobs.extend(d_jobs)
        all_image_jobs.extend(i_jobs)
        total_converted += stats.converted
        total_errors += stats.errors
        combined_stats.converted += stats.converted
        combined_stats.errors += stats.errors
        combined_stats.skip_reasons += stats.skip_reasons
        if on_scan:
            on_scan("raw", len(raw_files), len(all_docling_jobs) + len(all_image_jobs))

    doc_sources = load_doc_sources(project_path)
    for source in doc_sources.sources:
        source_files = _collect_source_files(source.path, on_file)
        source_target = input_dir / source.name
        # Archives from linked sources are extracted to raw/{source_name}/
        extract_to = raw_dir / source.name
        d_jobs, i_jobs, stats = _collect_jobs(
            source_files, source_target, on_file, extract_base=extract_to,
        )
        all_docling_jobs.extend(d_jobs)
        all_image_jobs.extend(i_jobs)
        total_converted += stats.converted
        total_errors += stats.errors
        combined_stats.converted += stats.converted
        combined_stats.errors += stats.errors
        combined_stats.skip_reasons += stats.skip_reasons
        if on_scan:
            on_scan(source.name, len(source_files), len(all_docling_jobs) + len(all_image_jobs))

    # Report scan results before starting conversion
    if on_scan_complete:
        on_scan_complete(
            len(all_docling_jobs), len(all_image_jobs),
            combined_stats.converted, combined_stats,
        )

    # Phase 2: parallel Docling conversion
    if all_docling_jobs and pool and pool.is_available:
        total_mb = sum(j.file_size for j in all_docling_jobs) / (1024 * 1024)
        logger.info(
            "Starte Docling-Konvertierung: %d Dateien (%.1f MB)...",
            len(all_docling_jobs), total_mb,
        )
        c, e = await pool.run_batch(all_docling_jobs, on_progress)
        total_converted += c
        total_errors += e
    elif all_docling_jobs:
        combined_stats.skip_reasons["kein Docling"] += len(all_docling_jobs)
        logger.debug(
            "Kein Docling verfuegbar — %d Dateien uebersprungen.", len(all_docling_jobs)
        )

    # Phase 3: parallel Ollama image description
    if all_image_jobs and ollama_pool and ollama_pool.is_available:
        total_mb = sum(j.file_size for j in all_image_jobs) / (1024 * 1024)
        logger.info(
            "Starte Ollama-Bildbeschreibung: %d Bilder (%.1f MB)...",
            len(all_image_jobs), total_mb,
        )
        c, e = await ollama_pool.run_batch(all_image_jobs, on_progress)
        total_converted += c
        total_errors += e
    elif all_image_jobs:
        combined_stats.skip_reasons["kein Ollama"] += len(all_image_jobs)
        logger.debug(
            "Kein Ollama verfuegbar — %d Bilder uebersprungen.", len(all_image_jobs)
        )

    total_skipped = combined_stats.skipped
    logger.info(
        "%s: %d konvertiert, %d uebersprungen, %d Fehler",
        project_path.name, total_converted, total_skipped, total_errors,
    )
    return total_converted, total_skipped, total_errors, combined_stats


def copy_files_to_raw(
    file_paths: list[Path],
    project_path: Path,
    move: bool = False,
) -> list[Path]:
    """Copy or move files into a project's raw/ directory.

    Args:
        file_paths: List of source file/directory paths.
        project_path: The project root directory.
        move: If True, move files (import). If False, copy (copy mode).

    Returns:
        List of files that were copied/moved.
    """
    raw_dir = project_path / RAW_DIRNAME
    raw_dir.mkdir(exist_ok=True)
    copied = []

    for source in file_paths:
        if source.is_file():
            target = raw_dir / source.name
            _transfer_file(source, target, move)
            copied.append(target)
        elif source.is_dir():
            for file_path in sorted(source.rglob("*")):
                if file_path.is_file():
                    rel = file_path.relative_to(source.parent)
                    target = raw_dir / rel
                    target.parent.mkdir(parents=True, exist_ok=True)
                    _transfer_file(file_path, target, move)
                    copied.append(target)
            # Remove empty source directory after move
            if move and source.is_dir():
                try:
                    shutil.rmtree(source)
                except OSError as exc:
                    logger.warning("Konnte Quellordner nicht loeschen: %s (%s)", source, exc)
    return copied


def _transfer_file(source: Path, target: Path, move: bool) -> None:
    """Copy or move a single file."""
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        if move:
            shutil.move(str(source), str(target))
            logger.debug("Verschoben: %s → %s", source, target)
        else:
            shutil.copy2(str(source), str(target))
            logger.debug("Kopiert: %s → %s", source, target)
    except OSError as exc:
        logger.warning("Fehler bei %s: %s", "Verschieben" if move else "Kopieren", exc)


def get_data_summary(project_path: Path) -> DataSummary:
    """Collect summary counts for a project's data (fast, no network I/O).

    Only traverses local directories (raw/, input/).  Linked sources are
    counted from doc-sources.yml without traversing their file trees, which
    could be on slow network shares or cloud drives.

    Returns:
        DataSummary with raw/linked/input counts and pending raw conversions.
    """
    raw_dir = project_path / RAW_DIRNAME
    input_dir = project_path / INPUT_DIRNAME

    raw_files = [f for f in raw_dir.rglob("*") if f.is_file()] if raw_dir.is_dir() else []
    doc_sources = load_doc_sources(project_path)
    input_files = [f for f in input_dir.rglob("*") if f.is_file()] if input_dir.is_dir() else []

    # Only count pending for local raw/ files (fast).
    # Linked sources may be on network/cloud — skip traversal here.
    pending = 0
    for f in raw_files:
        rel = f.relative_to(raw_dir)
        target = input_dir / RAW_DIRNAME / rel.with_suffix(".md")
        if _needs_conversion(f, target):
            pending += 1

    return DataSummary(
        raw_count=len(raw_files),
        linked_count=len(doc_sources.sources),
        linked_names=[s.name for s in doc_sources.sources],
        input_count=len(input_files),
        pending_count=pending,
    )


_DETAIL_FILE_LIMIT = 500


def get_data_detail(
    project_path: Path,
) -> list[tuple[str, str, list[tuple[str, str]]]]:
    """Collect detailed file listings with sync status per source.

    Linked sources are capped at _DETAIL_FILE_LIMIT files to avoid
    hanging on large network/cloud directories.

    Returns:
        List of (source_name, source_path_str, [(rel_filename, status), ...])
        where status is "aktuell", "veraltet", "neu", or "...".
    """
    raw_dir = project_path / RAW_DIRNAME
    input_dir = project_path / INPUT_DIRNAME

    result: list[tuple[str, str, list[tuple[str, str]]]] = []

    # Raw source (local, always full listing)
    if raw_dir.is_dir():
        files_status = []
        for f in sorted(raw_dir.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(raw_dir)
            target = input_dir / RAW_DIRNAME / rel.with_suffix(".md")
            if not target.exists():
                status = "neu"
            elif _needs_conversion(f, target):
                status = "veraltet"
            else:
                status = "aktuell"
            files_status.append((str(rel), status))
        result.append(("raw", str(raw_dir), files_status))

    # Linked sources (may be slow — cap file count)
    doc_sources = load_doc_sources(project_path)
    for source in doc_sources.sources:
        source_files = _collect_source_files(source.path)
        files_status = []
        truncated = len(source_files) > _DETAIL_FILE_LIMIT
        for abs_path, rel_path in source_files[:_DETAIL_FILE_LIMIT]:
            target = input_dir / source.name / rel_path.with_suffix(".md")
            if not target.exists():
                status = "neu"
            elif _needs_conversion(abs_path, target):
                status = "veraltet"
            else:
                status = "aktuell"
            files_status.append((str(rel_path), status))
        if truncated:
            remaining = len(source_files) - _DETAIL_FILE_LIMIT
            files_status.append((f"... und {remaining} weitere Dateien", "..."))
        result.append((source.name, str(source.path), files_status))

    return result
