"""7z-based project export.

Single source for the [Z] action and the `wsm export` CLI subcommand.
The action handler launches a separate terminal window running the
subcommand, which calls export_project() sequentially for each path.

UNC-safety:
- All filesystem ops use pathlib + shutil
- 7z is invoked via subprocess.run with explicit cwd=None and absolute
  paths as args; no shell=True, no `cd` indirection.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from wsm.models import Config
from wsm.paths import sanitize_name

logger = logging.getLogger("wsm")

# Pack flags: Ultra compression, solid block, multi-threaded
SEVENZIP_PACK_FLAGS = ["-mx=9", "-ms=on", "-mmt=on"]


# ---------------------------------------------------------------------------
# 7z binary resolution
# ---------------------------------------------------------------------------

_WINDOWS_TYPICAL = [
    Path(r"C:\Program Files\7-Zip\7z.exe"),
    Path(r"C:\Program Files (x86)\7-Zip\7z.exe"),
]
_LINUX_TYPICAL = [
    Path("/usr/bin/7z"),
    Path("/usr/local/bin/7z"),
    Path("/usr/bin/7zz"),
    Path("/usr/local/bin/7zz"),
]
_PATH_NAMES = ["7z", "7zz", "7za"]


def find_sevenzip_binary(config: Config) -> Path | None:
    """Resolve the 7z binary.

    Order: config.sevenzip_path > platform-typical paths > shutil.which.
    Returns None if nothing usable is found.
    """
    if config.sevenzip_path:
        if config.sevenzip_path.exists():
            return config.sevenzip_path
        logger.warning(
            "sevenzip_path aus Config nicht gefunden: %s", config.sevenzip_path,
        )

    typical = _WINDOWS_TYPICAL if sys.platform == "win32" else _LINUX_TYPICAL
    for candidate in typical:
        if candidate.exists():
            return candidate

    for name in _PATH_NAMES:
        which = shutil.which(name)
        if which:
            return Path(which)

    return None


def verify_sevenzip(binary: Path) -> bool:
    """Run a smoke test on the 7z binary; returns True if it responds."""
    try:
        result = subprocess.run(
            [str(binary)],
            capture_output=True,
            text=True,
            timeout=10,
        )
        # 7z prints help to stdout when called without args; exit code is 0
        # for newer versions, non-zero for older — both fine. We just want
        # to ensure it ran.
        return bool(result.stdout) or result.returncode == 0
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.warning("7z Smoke-Test fehlgeschlagen: %s", exc)
        return False


# ---------------------------------------------------------------------------
# Archive name construction
# ---------------------------------------------------------------------------

def _timestamp(now: datetime | None = None) -> str:
    """Return YYYY-MM-DD-HH-MM-SS local-time stamp."""
    return (now or datetime.now()).strftime("%Y-%m-%d-%H-%M-%S")


def build_archive_name(
    location_name: str,
    project_name: str,
    export_path: Path,
    now: datetime | None = None,
) -> Path:
    """Build the target archive path.

    Schema:  {export_path}/{YYYY-MM-DD-HH-MM-SS} - {location} - {project}.7z

    location_name and project_name are sanitize_name'd before assembly.
    On collision (same second twice), suffix " (2)", " (3)", … is added
    before the extension.
    """
    loc_clean = sanitize_name(location_name) or "location"
    proj_clean = sanitize_name(project_name) or "project"
    base = f"{_timestamp(now)} - {loc_clean} - {proj_clean}"
    candidate = export_path / f"{base}.7z"
    if not candidate.exists():
        return candidate
    i = 2
    while True:
        candidate = export_path / f"{base} ({i}).7z"
        if not candidate.exists():
            return candidate
        i += 1


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

class ExportError(Exception):
    """Raised when an export cannot start (config/binary issues)."""


def preflight(config: Config) -> Path:
    """Validate prerequisites; return the resolved 7z binary path.

    Raises ExportError with a user-friendly message if anything is missing.
    """
    if config.export_path is None:
        raise ExportError(
            "export_path ist nicht in der Konfiguration gesetzt. "
            "Bitte 'export_path: ~/exports' (oder ein anderes Verzeichnis) "
            "in ~/.workspacemanager.yml ergaenzen."
        )

    binary = find_sevenzip_binary(config)
    if binary is None:
        raise ExportError(
            "7z-Binary nicht gefunden. Bitte 7-Zip installieren oder "
            "'sevenzip_path: /pfad/zu/7z' in der Konfiguration setzen."
        )

    if not verify_sevenzip(binary):
        raise ExportError(
            f"7z-Binary {binary} ist nicht funktionsfaehig (Smoke-Test "
            "fehlgeschlagen)."
        )

    try:
        config.export_path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise ExportError(
            f"Export-Verzeichnis kann nicht angelegt werden ({config.export_path}): "
            f"{exc}"
        ) from exc

    return binary


def export_project(
    project_path: Path,
    config: Config,
    binary: Path,
) -> tuple[bool, Path | None, str]:
    """Pack one project into a 7z archive.

    Returns (success, archive_path, message).
    `binary` must be the result of find_sevenzip_binary(); preflight() should
    have been called once before.

    The location name is recovered by walking up the path: it is the parent
    directory's name. This avoids needing to wire Location through here.
    """
    if not project_path.exists() or not project_path.is_dir():
        return False, None, f"Projektpfad existiert nicht: {project_path}"

    location_name = project_path.parent.name
    archive_path = build_archive_name(
        location_name, project_path.name, config.export_path,
    )

    # 7z syntax:  7z a [flags] <archive> <files-to-add>
    # We pack the directory contents (".") with cwd set to the project so
    # the archive contains paths relative to the project root, not the
    # absolute filesystem path.
    args = [
        str(binary), "a", *SEVENZIP_PACK_FLAGS,
        str(archive_path),
        ".",
    ]

    print(f"\n[{project_path.name}] -> {archive_path.name}")
    print(f"  > {' '.join(args)}")

    try:
        result = subprocess.run(
            args,
            cwd=str(project_path),
            text=True,
        )
    except OSError as exc:
        return False, archive_path, f"7z konnte nicht gestartet werden: {exc}"

    # 7z exit codes:
    #   0 = no error
    #   1 = warning (non-fatal: archive was written, but some files had
    #       issues -- e.g. symlinks pointing nowhere, or files locked by
    #       other processes). The archive is intact and usable.
    #   2 = fatal error
    #   7 = command line error
    #   8 = not enough memory
    if result.returncode == 0:
        return True, archive_path, "ok"
    if result.returncode == 1:
        return True, archive_path, "ok (mit Warnungen)"
    return False, archive_path, f"7z exit code {result.returncode}"


def run_export(paths: list[Path], config: Config) -> int:
    """Entry point for the `wsm export <path...>` subcommand.

    Sequentially exports each path. Returns 0 if all succeed, 1 if any
    failed. Errors during preflight (missing config, missing binary)
    return 2.
    """
    try:
        binary = preflight(config)
    except ExportError as exc:
        print(f"[Fehler] {exc}", file=sys.stderr)
        return 2

    n = len(paths)
    failures: list[tuple[Path, str]] = []

    for i, path in enumerate(paths, start=1):
        print(f"\n[{i}/{n}] {path.name}: packe ...")
        ok, archive, message = export_project(path, config, binary)
        if ok:
            size = archive.stat().st_size if archive and archive.exists() else 0
            print(f"  -> {message}  ({_human_size(size)})")
        else:
            print(f"  -> FEHLER: {message}")
            failures.append((path, message))

    print("\nZusammenfassung:")
    print(f"  Exportiert: {n - len(failures)}/{n}")
    if failures:
        print("  Fehler:")
        for path, message in failures:
            print(f"    {path.name}: {message}")
        return 1
    return 0


def _human_size(num: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} PB"
