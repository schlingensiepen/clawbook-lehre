"""Read file and folder paths from the system clipboard."""

from pathlib import Path

from wsm.platform import get_platform


def read_clipboard_paths() -> list[Path]:
    """Read file/folder paths from the system clipboard.

    Windows: Uses PowerShell to access the clipboard's file drop list.
    Linux: Uses xclip or xsel.

    Returns:
        List of Path objects for each file/folder in the clipboard.
        Empty list if clipboard is empty or contains no files.
    """
    return get_platform().read_clipboard_paths()


def classify_clipboard_paths(
    paths: list[Path],
) -> tuple[list[Path], list[Path]]:
    """Separate clipboard paths into files and directories.

    Returns:
        Tuple of (files, directories).
    """
    files = [p for p in paths if p.is_file()]
    dirs = [p for p in paths if p.is_dir()]
    return files, dirs
