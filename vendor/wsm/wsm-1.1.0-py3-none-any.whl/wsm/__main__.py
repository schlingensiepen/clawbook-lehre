"""Entry point for python -m wsm."""

import sys

from wsm.cli import main

sys.exit(main())
