"""Path conversion (Windows/WSL) and name sanitizing utilities."""

import os
import re
from pathlib import Path, PureWindowsPath

# Umlaut and special character replacement map
_CHAR_MAP = {
    "ä": "ae",
    "ö": "oe",
    "ü": "ue",
    "ß": "ss",
    "&": "und",
}


def sanitize_name(name: str) -> str:
    """Sanitize a project name for use as directory and git repo name.

    Rules:
        1. Lowercase
        2. Resolve umlauts (ä→ae, ö→oe, ü→ue, ß→ss)
        3. & → und
        4. Spaces → hyphens
        5. Remove everything except [a-z0-9-]
        6. Collapse multiple hyphens
        7. Strip leading/trailing hyphens
    """
    result = name.lower()
    for char, replacement in _CHAR_MAP.items():
        result = result.replace(char, replacement)
    result = result.replace(" ", "-")
    result = re.sub(r"[^a-z0-9-]", "", result)
    result = re.sub(r"-{2,}", "-", result)
    result = result.strip("-")
    return result


def expand_tilde(path_str: str) -> Path:
    """Expand ~ to the Windows user profile directory.

    On Windows, ~ resolves to %USERPROFILE%.
    On WSL/Linux, ~ resolves to $HOME (via os.path.expanduser).
    """
    if path_str.startswith("~"):
        user_home = os.environ.get("USERPROFILE", os.path.expanduser("~"))
        path_str = path_str.replace("~", user_home, 1)
    return Path(path_str)


def windows_to_wsl(path: Path | str) -> str:
    """Convert a Windows path to a WSL mount path.

    Examples:
        C:\\Users\\joern  →  /mnt/c/Users/joern
        D:\\Projekte      →  /mnt/d/Projekte
    """
    win_path = PureWindowsPath(path)
    if win_path.drive:
        drive_letter = win_path.drive[0].lower()
        rest = win_path.as_posix().split("/", 1)
        tail = rest[1] if len(rest) > 1 else ""
        return f"/mnt/{drive_letter}/{tail}"
    # Already a posix-style path, return as-is
    return str(path).replace("\\", "/")


def wsl_to_windows(wsl_path: str) -> PureWindowsPath:
    """Convert a WSL mount path back to a Windows path.

    Returns PureWindowsPath for consistent behavior across platforms.

    Examples:
        /mnt/c/Users/joern  →  C:\\Users\\joern
        /mnt/d/Projekte     →  D:\\Projekte
    """
    match = re.match(r"^/mnt/([a-z])/?(.*)", wsl_path)
    if match:
        drive = match.group(1).upper()
        rest = match.group(2).replace("/", "\\")
        return PureWindowsPath(f"{drive}:\\{rest}") if rest else PureWindowsPath(f"{drive}:\\")
    return PureWindowsPath(wsl_path)


def is_unc_path(path: Path | str) -> bool:
    """Check if a path is a UNC path (\\\\server\\share)."""
    path_str = str(path)
    return path_str.startswith("\\\\") or path_str.startswith("//")
