"""Docling server client with parallel worker queue for batch conversion.

File classification (`is_passthrough`, `categorize_file`, `extract_archive`,
etc.) has moved to `wsm.classify` — a network-free module. This module
re-exports those symbols for backwards compatibility, but new consumers
that only need classification should import from `wsm.classify` directly
to avoid pulling in `httpx`.
"""

import asyncio
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

import httpx

# Re-export classification and archive-extraction symbols so existing
# consumers of `wsm.converter` continue to work unchanged.
from wsm.classify import (  # noqa: F401
    ARCHIVE_EXTENSIONS_7Z,
    ARCHIVE_EXTENSIONS_RAR,
    ARCHIVE_EXTENSIONS_STDLIB,
    CATEGORY_ARCHIVE,
    CATEGORY_DOCLING,
    CATEGORY_IMAGE,
    CATEGORY_PASSTHROUGH,
    CATEGORY_SKIP,
    CATEGORY_UNSUPPORTED,
    DOCLING_SUPPORTED,
    IMAGE_EXTENSIONS,
    PASSTHROUGH_EXTENSIONS,
    SKIP_EXTENSIONS,
    SKIP_FILENAMES,
    SKIP_PREFIXES,
    _archive_type,
    categorize_file,
    extract_archive,
    is_archive,
    is_docling_supported,
    is_image,
    is_passthrough,
    is_skippable,
)

logger = logging.getLogger("wsm")

HEALTH_ENDPOINT = "/health"
CONVERT_ENDPOINT = "/v1/convert/file"
ASYNC_CONVERT_ENDPOINT = "/v1/convert/file/async"
POLL_ENDPOINT = "/v1/status/poll/{task_id}"
RESULT_ENDPOINT = "/v1/result/{task_id}"

HEALTH_TIMEOUT = 15.0
CONVERT_TIMEOUT = 300.0
POLL_INTERVAL = 2.0


async def check_server_health(server_url: str) -> bool:
    """Check if a docling server is reachable and healthy."""
    try:
        async with httpx.AsyncClient(timeout=HEALTH_TIMEOUT) as client:
            resp = await client.get(f"{server_url}{HEALTH_ENDPOINT}")
            if resp.status_code == 200:
                data = resp.json()
                return data.get("status") == "ok"
            logger.debug(
                "Docling-Server %s antwortet HTTP %d (nicht ok).",
                server_url, resp.status_code,
            )
    except (httpx.ConnectError, httpx.ConnectTimeout) as exc:
        logger.debug("Docling-Server %s nicht erreichbar: %s", server_url, exc)
    except httpx.RequestError as exc:
        logger.debug("Docling-Server %s Request-Fehler: %s", server_url, exc)
    return False


async def get_healthy_servers(server_urls: list[str]) -> list[str]:
    """Filter server list to only healthy servers."""
    if not server_urls:
        return []

    results = await asyncio.gather(
        *[check_server_health(url) for url in server_urls],
        return_exceptions=True,
    )

    healthy = []
    for url, result in zip(server_urls, results):
        if result is True:
            healthy.append(url)
            logger.debug("Server healthy: %s", url)
        else:
            logger.warning("Server nicht erreichbar: %s", url)

    return healthy


async def convert_file(server_url: str, file_path: Path) -> str | None:
    """Convert a single file via docling and return markdown content.

    Raises httpx.ConnectError / httpx.ConnectTimeout on connection failure
    so callers can distinguish server-down from file-level errors.
    Returns None on file-level conversion failure.
    """
    async with httpx.AsyncClient(timeout=CONVERT_TIMEOUT) as client:
        try:
            with open(file_path, "rb") as f:
                resp = await client.post(
                    f"{server_url}{CONVERT_ENDPOINT}",
                    files={"files": (file_path.name, f)},
                )
        except (httpx.ConnectError, httpx.ConnectTimeout):
            raise  # let worker handle server-down
        except httpx.RequestError as exc:
            logger.warning("Docling request error for %s: %s", file_path.name, exc)
            return None

        if resp.status_code != 200:
            logger.warning(
                "Docling conversion failed for %s (HTTP %d): %s",
                file_path.name,
                resp.status_code,
                resp.text[:200],
            )
            return None

        data = resp.json()
        status = data.get("status", "")
        if status not in ("success", "partial_success"):
            logger.warning(
                "Docling conversion status '%s' for %s",
                status,
                file_path.name,
            )
            return None

        md_content = data.get("document", {}).get("md_content")
        if md_content is None:
            logger.warning("No markdown content in response for %s", file_path.name)
            return None

        return md_content


@dataclass
class ConversionJob:
    """A single file to be converted via Docling."""

    source_path: Path
    target_path: Path
    file_size: int
    footer: str


@dataclass
class _ProgressState:
    """Shared mutable state for worker progress tracking."""

    total_bytes: int = 0
    completed_bytes: int = 0
    completed_files: int = 0
    total_files: int = 0
    converted: int = 0
    errors: int = 0
    callback: Callable[[int, int, int, int], None] | None = None

    def notify(self) -> None:
        if self.callback:
            remaining = self.total_files - self.completed_files
            self.callback(
                self.completed_bytes,
                self.total_bytes,
                self.completed_files,
                remaining,
            )


class DoclingPool:
    """Worker-queue pool of docling servers for parallel batch conversion."""

    def __init__(
        self,
        server_urls: list[str],
        workers_per_server: int = 2,
        retry_timeout: int = 180,
    ):
        self._all_servers = list(server_urls)
        self._healthy_servers: list[str] = []
        self._workers_per_server = workers_per_server
        self._retry_timeout = retry_timeout

    async def initialize(self) -> int:
        """Check health of all servers. Returns number of healthy servers."""
        self._healthy_servers = await get_healthy_servers(self._all_servers)
        count = len(self._healthy_servers)
        if count == 0 and self._all_servers:
            logger.warning("Kein Docling-Server erreichbar!")
        else:
            logger.info(
                "%d von %d Docling-Servern erreichbar (%d Worker gesamt).",
                count,
                len(self._all_servers),
                count * self._workers_per_server,
            )
        return count

    @property
    def is_available(self) -> bool:
        """True if at least one server is healthy."""
        return len(self._healthy_servers) > 0

    async def run_batch(
        self,
        jobs: list[ConversionJob],
        on_progress: Callable[[int, int, int, int], None] | None = None,
    ) -> tuple[int, int]:
        """Run all conversion jobs in parallel across workers.

        Returns:
            Tuple of (converted, errors).
        """
        if not jobs or not self._healthy_servers:
            return 0, 0

        queue: asyncio.Queue[ConversionJob] = asyncio.Queue()
        for job in jobs:
            queue.put_nowait(job)

        state = _ProgressState(
            total_bytes=sum(j.file_size for j in jobs),
            total_files=len(jobs),
            callback=on_progress,
        )

        workers = []
        for server_url in self._healthy_servers:
            for _ in range(self._workers_per_server):
                workers.append(self._worker(server_url, queue, state))

        await asyncio.gather(*workers)
        return state.converted, state.errors

    async def _worker(
        self,
        server_url: str,
        queue: asyncio.Queue[ConversionJob],
        state: _ProgressState,
    ) -> None:
        """Worker coroutine: pull jobs from queue and convert via assigned server."""
        while True:
            try:
                job = queue.get_nowait()
            except asyncio.QueueEmpty:
                break

            logger.info("Konvertiere: %s", job.source_path.name)

            try:
                md_content = await convert_file(server_url, job.source_path)
            except (httpx.ConnectError, httpx.ConnectTimeout):
                # Server down — in-flight job is lost
                state.errors += 1
                state.completed_bytes += job.file_size
                state.completed_files += 1
                state.notify()
                queue.task_done()

                logger.warning(
                    "Server %s ausgefallen, warte %ds...",
                    server_url,
                    self._retry_timeout,
                )
                await asyncio.sleep(self._retry_timeout)

                if await check_server_health(server_url):
                    logger.info("Server %s wieder erreichbar.", server_url)
                    continue
                else:
                    logger.warning(
                        "Server %s weiterhin nicht erreichbar, Worker beendet.",
                        server_url,
                    )
                    break

            if md_content is not None:
                job.target_path.parent.mkdir(parents=True, exist_ok=True)
                job.target_path.write_text(
                    md_content + job.footer, encoding="utf-8"
                )
                state.converted += 1
            else:
                state.errors += 1
                logger.warning("Konvertierung fehlgeschlagen: %s", job.source_path.name)

            state.completed_bytes += job.file_size
            state.completed_files += 1
            state.notify()
            queue.task_done()


# ── Ollama vision client ─────────────────────────────────────────────

OLLAMA_CHAT_ENDPOINT = "/api/chat"
OLLAMA_TIMEOUT = 120.0
OLLAMA_DESCRIBE_PROMPT = (
    "Describe this image in detail. "
    "If it contains text, include all readable text. "
    "If it is a diagram or chart, describe its structure and data. "
    "Respond in the same language as any text in the image, "
    "otherwise respond in German."
)


async def check_ollama_health(server_url: str) -> bool:
    """Check if an Ollama server is reachable."""
    try:
        async with httpx.AsyncClient(timeout=HEALTH_TIMEOUT) as client:
            resp = await client.get(server_url)
            return resp.status_code == 200
    except (httpx.RequestError, Exception) as exc:
        logger.debug("Ollama health check failed for %s: %s", server_url, exc)
    return False


async def get_healthy_ollama_servers(server_urls: list[str]) -> list[str]:
    """Filter Ollama server list to only reachable servers."""
    if not server_urls:
        return []

    results = await asyncio.gather(
        *[check_ollama_health(url) for url in server_urls],
        return_exceptions=True,
    )

    healthy = []
    for url, result in zip(server_urls, results):
        if result is True:
            healthy.append(url)
            logger.debug("Ollama server healthy: %s", url)
        else:
            logger.warning("Ollama-Server nicht erreichbar: %s", url)
    return healthy


async def describe_image(server_url: str, model: str, file_path: Path) -> str | None:
    """Describe an image via Ollama vision model. Returns markdown text or None."""
    import base64

    try:
        image_b64 = base64.b64encode(file_path.read_bytes()).decode("utf-8")
    except OSError as exc:
        logger.warning("Fehler beim Lesen von %s: %s", file_path.name, exc)
        return None

    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": OLLAMA_DESCRIBE_PROMPT,
                "images": [image_b64],
            }
        ],
        "stream": False,
    }

    try:
        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            resp = await client.post(
                f"{server_url}{OLLAMA_CHAT_ENDPOINT}",
                json=payload,
            )
        if resp.status_code != 200:
            logger.warning(
                "Ollama request failed for %s (HTTP %d)",
                file_path.name, resp.status_code,
            )
            return None

        data = resp.json()
        content = data.get("message", {}).get("content", "")
        if not content:
            return None

        return f"# {file_path.name}\n\n{content}"

    except (httpx.ConnectError, httpx.ConnectTimeout):
        raise
    except httpx.RequestError as exc:
        logger.warning("Ollama request error for %s: %s", file_path.name, exc)
        return None


class OllamaPool:
    """Worker-queue pool of Ollama servers for parallel image description."""

    def __init__(
        self,
        server_urls: list[str],
        model: str = "llava",
        workers_per_server: int = 1,
        retry_timeout: int = 180,
    ):
        self._all_servers = list(server_urls)
        self._healthy_servers: list[str] = []
        self._model = model
        self._workers_per_server = workers_per_server
        self._retry_timeout = retry_timeout

    async def initialize(self) -> int:
        """Check reachability of all servers. Returns number of healthy servers."""
        self._healthy_servers = await get_healthy_ollama_servers(self._all_servers)
        count = len(self._healthy_servers)
        if count == 0 and self._all_servers:
            logger.warning("Kein Ollama-Server erreichbar!")
        elif self._all_servers:
            logger.info(
                "%d von %d Ollama-Servern erreichbar (Modell: %s).",
                count, len(self._all_servers), self._model,
            )
        return count

    @property
    def is_available(self) -> bool:
        return len(self._healthy_servers) > 0

    async def run_batch(
        self,
        jobs: list[ConversionJob],
        on_progress: Callable[[int, int, int, int], None] | None = None,
    ) -> tuple[int, int]:
        """Run all image description jobs in parallel. Returns (converted, errors)."""
        if not jobs or not self._healthy_servers:
            return 0, 0

        queue: asyncio.Queue[ConversionJob] = asyncio.Queue()
        for job in jobs:
            queue.put_nowait(job)

        state = _ProgressState(
            total_bytes=sum(j.file_size for j in jobs),
            total_files=len(jobs),
            callback=on_progress,
        )

        workers = []
        for server_url in self._healthy_servers:
            for _ in range(self._workers_per_server):
                workers.append(self._worker(server_url, queue, state))

        await asyncio.gather(*workers)
        return state.converted, state.errors

    async def _worker(
        self,
        server_url: str,
        queue: asyncio.Queue[ConversionJob],
        state: _ProgressState,
    ) -> None:
        while True:
            try:
                job = queue.get_nowait()
            except asyncio.QueueEmpty:
                break

            logger.info("Beschreibe: %s", job.source_path.name)

            try:
                md_content = await describe_image(
                    server_url, self._model, job.source_path,
                )
            except (httpx.ConnectError, httpx.ConnectTimeout):
                state.errors += 1
                state.completed_bytes += job.file_size
                state.completed_files += 1
                state.notify()
                queue.task_done()

                logger.warning(
                    "Ollama-Server %s ausgefallen, warte %ds...",
                    server_url, self._retry_timeout,
                )
                await asyncio.sleep(self._retry_timeout)

                if await check_ollama_health(server_url):
                    logger.info("Ollama-Server %s wieder erreichbar.", server_url)
                    continue
                else:
                    logger.warning(
                        "Ollama-Server %s weiterhin nicht erreichbar, Worker beendet.",
                        server_url,
                    )
                    break

            if md_content is not None:
                job.target_path.parent.mkdir(parents=True, exist_ok=True)
                job.target_path.write_text(
                    md_content + job.footer, encoding="utf-8",
                )
                state.converted += 1
                logger.debug("Bild beschrieben: %s", job.source_path.name)
            else:
                state.errors += 1
                logger.warning("Bildbeschreibung fehlgeschlagen: %s", job.source_path.name)

            state.completed_bytes += job.file_size
            state.completed_files += 1
            state.notify()
            queue.task_done()
