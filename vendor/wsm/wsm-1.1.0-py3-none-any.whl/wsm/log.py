"""Logging configuration for terminal and file output."""

import logging
import sys
from pathlib import Path

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_logger = logging.getLogger("wsm")


def setup_logging(
    log_file: Path | None = None,
    verbose: bool = False,
) -> logging.Logger:
    """Configure dual logging to terminal and optional file.

    Args:
        log_file: Path to log file (None disables file logging).
        verbose: If True, log DEBUG level; otherwise INFO.

    Returns:
        The configured logger instance.
    """
    console_level = logging.DEBUG if verbose else logging.INFO

    # Logger itself must allow DEBUG so the file handler can capture everything
    _logger.setLevel(logging.DEBUG)

    # Remove existing handlers (avoid duplicates on re-init)
    _logger.handlers.clear()

    # Terminal handler (stderr so it doesn't mix with TUI on stdout)
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(console_level)
    console.setFormatter(logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT))
    _logger.addHandler(console)

    # File handler (if configured)
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)  # always verbose in file
        file_handler.setFormatter(logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT))
        _logger.addHandler(file_handler)

    return _logger


def get_logger() -> logging.Logger:
    """Return the wsm logger instance."""
    return _logger
